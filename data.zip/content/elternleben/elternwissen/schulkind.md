---
author: ''
category:
- elternwissen
crawled_at: '2025-03-05T19:53:54.211274'
description: ''
filename: schulkind.md
filepath: elternleben/elternwissen/schulkind.md
title: Schulkind
url: https://www.elternleben.de/elternwissen/schulkind/
---

#  Elternwissen

