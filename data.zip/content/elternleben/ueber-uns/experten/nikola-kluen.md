---
author: ''
category:
- ueber-uns
- experten
crawled_at: '2025-03-05T20:32:35.594252'
description: Dr. Nikola Klün ist auf ElternLeben.de Expertin rund um die Themen Kindergesundheit,
  Kindermedizin und kindliche Entwicklung.
filename: nikola-kluen.md
filepath: elternleben/ueber-uns/experten/nikola-kluen.md
title: Nikola Klün
url: https://www.elternleben.de/ueber-uns/experten/nikola-kluen/
---

##  Dr. Nikola Klün

[ ![](/fileadmin/_processed_/f/9/csm_Dr._Nikola_Klu__n_stellt_sich_vor_-
_Expertin_auf_ElternLeben.de_3caf02b308.png) ](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))

![Nikola
Klün](/fileadmin/_processed_/d/d/csm_Nikola_Klu__n_Close_5f37fc1b3a.jpeg)

Dr. Nikola Klün

Online-Beratung & Autorin

Dr. Nikola Klün ist auf ElternLeben.de Expertin rund um die Themen
**Kindergesundheit** , **Kindermedizin und kindliche Entwicklung**. Sie berät
in unserer Online-Beratung und schreibt für unseren Wissens-Bereich.  
  
Sie ist Assistenzärztin in der Kindermedizin und arbeitet seit vier Jahren in
einer Kinderklinik bei München. Sie absolviert außerdem eine Weiterbildung zur
Kinder- und Jugendpsychotherapeutin und zur Ernährungsmedizinerin.  
  
Nikola Klün ist seit Kurzem Mutter eines kleinen Sohns. Ihr liegt besonders am
Herzen, Kindermedizin so zu erklären, dass Eltern Kindergesundheit und
Kinderkrankheiten verstehen können und unbegründete Sorgen durch Wissen
genommen werden.  
  
In ihrem privaten Blog
[kinderleibundseele.com](https://www.kinderleibundseele.com/ "Opens external
link in new window") schreibt sie über ihre Erfahrungen als Mutter und über
kindermedizinische Themen.  
  
Nikola "live": [hier stellt sich Nikola persönlich im Video
vor](https://www.elternleben.de/ueber-uns/experten/nikola-kluen/)!

