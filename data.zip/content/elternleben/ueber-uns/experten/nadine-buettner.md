---
author: ''
category:
- ueber-uns
- experten
crawled_at: '2025-03-05T20:25:24.232660'
description: Nadine Büttner ist auf ElternLeben.de Expertin rund um das Thema konkreter
  Erziehungsfragen im Alltag. Sie ist erfahrene Diplom Sozialpädagogin, Montessori
  Pädagogin, Safe® Mentorin & NLP Practitioner.
filename: nadine-buettner.md
filepath: elternleben/ueber-uns/experten/nadine-buettner.md
title: Nadine Büttner
url: https://www.elternleben.de/ueber-uns/experten/nadine-buettner/
---

##  Nadine Büttner

[ ![](/fileadmin/_processed_/3/d/csm_Nadine_Bu__ttner_stellt_sich_vor-
_Expertin_auf_ElternLeben.de_d5dcaee0fe.png) ](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))



Nadine Büttner

Online-Beratung & Autorin

Nadine Büttner ist auf ElternLeben.de Expertin rund um das Thema konkreter
**Erziehungsfragen im Alltag**. Für ElternLeben.de schreibt sie Inhalte für
den Bereich Elternwissen. Auch aus ihrer Feder geflossen ist das [
](https://www.elternleben.de/shop/handbuch-alltag-mit-kleinkind/ "Opens
external link in new window")**[>>Handbuch Spielen, Lernen, Wachsen – Dein
Alltag mit Kleinkind](https://www.elternleben.de/shop/handbuch-alltag-mit-
kleinkind/ "Opens external link in new window")**.

Sie ist erfahrene Diplom Sozialpädagogin, Montessori Pädagogin, Safe® Mentorin
& NLP Practitioner. Mit mehrjähriger Führungserfahrung im Bereich der
ambulanten Kinder- und Jugendhilfe, engagiert sie sich freiberuflich für
Eltern und pädagogische Fachkräfte. Zudem begleitet die dreifach Mama
Führungspersonen im Bereich der Gesprächsführung und Selbstfürsorge.

Nadine Büttner hat bewusst eine lange Elternzeit mit ihren drei Kindern
genossen. Sie liebt das Reisen mit Kindern und setzt sich stark dafür ein,
dass sie schon von Anfang an als individuelle Persönlichkeiten wahrgenommen
werden.

Nadine "live":**[hier stellt sich Nadine persönlich im Video
vor](https://www.elternleben.de/ueber-uns/experten/nadine-buettner/)!**

