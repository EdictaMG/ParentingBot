---
author: ''
category:
- live
crawled_at: '2025-03-05T19:44:49.982663'
description: Was sind die typischen Stressfallen für Eltern und wie findet man da
  wieder heraus? Wie gelingt Achtsamkeit im Alltag mit Kindern?
filename: selbstfuersorge-fuer-eltern.md
filepath: elternleben/live/selbstfuersorge-fuer-eltern.md
title: Selbstfürsorge für Eltern
url: https://www.elternleben.de/live/selbstfuersorge-fuer-eltern/
---

![Versteckende Frau unter ihrer
Decke](/fileadmin/_processed_/9/9/csm_Keyvisual_Video-
Seminar_Selbstfu__rsorge_taisiia-stupak-sePA_raTCUk-
unsplash_cut_1e371b20cc.jpg)

#  Selbstfürsorge für Eltern Kostenfreies Live-Seminar

Am 15.12. um 20:00

Erhalte wertvolle Impulse und stelle Expertin Dr. Martina Stotz deine Fragen
via zoom

**Am Donnerstag, 15.12. um 20:00  
Dauer: ca. 90 Minuten**

[Jetzt unverbindlich
anmelden](https://us06web.zoom.us/webinar/register/WN_b-V9bamAR46F3I9gnKYofA)

Keine Zeit? Melde dich gern dennoch an.  
Dann erhältst du nach dem Seminar einen Link zur Aufzeichnung und den
Seminarunterlagen!

##  Unsere Themen:

  * Was sind die typischen Stressfallen für Eltern und wie findet man da wieder heraus?
  * Wie gelingt Achtsamkeit im Alltag mit Kindern?
  * Wie kann ich Stress in der Familie vorbeugen?
  * Was kann mir sofort helfen, wenn ich bereits gestresst bin?
  * Wie überwinde ich blockierende Muster, die mich immer wieder im Stress enden lassen?
  * Wir finden DEINE individuellen Ansatzpunkte auf 4 Ebenen, um vom Stress in die Ausgeglichenkeit zu kommen.

Diese und viele weitere Fragen behandeln wir in diesem kostenlosen Live-
Seminar mit **Dr. Martina Stotz**.

Neben kurzen Impulsvorträgen zu den wichtigsten Themen der Selbstfürsorge wird
es viel Raum für deine individuellen Fragen geben.

Triff Martina im Live-Seminar und stelle alle deine Fragen: Martina
beantwortet sie live!

Du selbst möchtest im Seminar nicht zu sehen und zu hören sein? Kein Problem!
Stelle deine Fragen gern schriftlich über den Chat!

Wir freuen uns auf dich und deine Fragen!

[Jetzt unverbindlich
anmelden](https://us06web.zoom.us/webinar/register/WN_b-V9bamAR46F3I9gnKYofA)

Keine Zeit? Melde dich gern dennoch an. Dann erhältst du nach dem Seminar
einen Link zur Aufzeichnung und den Seminarunterlagen!

![Dr. Martina
Stotz](/fileadmin/_processed_/7/1/csm_Martina_2020_0af02644e3.png)

Dr. Martina Stotz ist Doktorin der Pädagogik sowie erfahrene Familien-
Erziehungs- und Paarberaterin. Ihre Vision ist es, so viele Eltern wie möglich
kompetent und einfühlsam zu begleiten, damit sie Selbstsicherheit und
Vertrauen in ihre eigenen Fähigkeiten entwickeln und sie und ihre Kinder
darüber Liebe, Geborgenheit und Leichtigkeit erfahren.

[Jetzt unverbindlich
anmelden](https://us06web.zoom.us/webinar/register/WN_b-V9bamAR46F3I9gnKYofA)

