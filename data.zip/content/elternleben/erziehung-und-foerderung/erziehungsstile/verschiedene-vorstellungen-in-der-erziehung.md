---
author: ''
category:
- erziehung-und-foerderung
- erziehungsstile
crawled_at: '2025-03-05T20:36:54.553012'
description: Dr. Martina Stotz erzählt in diesem Impuls-Video was Paare tun können,
  wenn sie unterschiedliche Erziehungsvorstellungen haben.
filename: verschiedene-vorstellungen-in-der-erziehung.md
filepath: elternleben/erziehung-und-foerderung/erziehungsstile/verschiedene-vorstellungen-in-der-erziehung.md
title: Erziehung – verschiedene Vorstellungen – Dr. Martina Stotz
url: https://www.elternleben.de/erziehung-und-foerderung/erziehungsstile/verschiedene-vorstellungen-in-der-erziehung/
---

#  Erziehung – verschiedene Vorstellungen – Dr. Martina Stotz

Dr. Martina Stotz erzählt in diesem Impuls-Video was Paare tun können, wenn
sie unterschiedliche Erziehungsvorstellungen haben. Versucht in Gesprächen
herauszufinden, welche Werte ihr habt. Stellt euch die Frage: Was ist uns
wichtig? Sind Werte klar definiert, können Kinder gut verstehen, wenn Eltern
nicht immer gleich reagieren. **Lies auch unseren Artikel Erziehung –
Pädagogische Ansätze zur Kindererziehung**

[
![](/fileadmin/_processed_/a/d/csm_Wenn_der_Partner_andere_Erziehungsvorstellungen_hat_-
_Dr._Martina_Stotz_8f8259595c.png) ](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))

##  ElternLeben Expertin – Dr. Martina Stotz

Martina Stotz ist auf ElternLeben.de die Expertin rund um **schulische
Probleme** und familiäre Herausforderungen und berät zu diesen Themen in
unserer **Online-Beratung**. Darüber hinaus schreibt sie Inhalte für unseren
Wissensbereich. Sie ist Doktorin der Familienpsychologie und Expertin bei
allen **Geschwister- sowie Partnerschaftsthemen**.  
  
Im Bereich der Schulpsychologie berät sie bei ADHS/ADS, Schul- und
Prüfungsangst, Konzentrations- und Motivationsproblemen, LRS und
Verhaltensauffälligkeiten. Sie hält **Erziehungskurse** und Vorträge für
Eltern sowie Fortbildungen für Pädagogen in München (Thema: „Achtsame
Kommunikation mit Kindern“). Auf ihrem Blog „Mein Erziehungsratgeber“,
Instagram und YouTube berichtet sie zu ihren Herzensthemen und bietet
telefonische Einzelberatung an.

