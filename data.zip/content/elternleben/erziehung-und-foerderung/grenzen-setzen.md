---
author: ''
category:
- erziehung-und-foerderung
crawled_at: '2025-03-05T19:53:07.690136'
description: In fünf Schritten zeigt dir Dr. Martina Stotz in diesem Impuls-Video,
  wie du deinem Kind gewaltfrei deine innere Grenze zeigen kannst.
filename: grenzen-setzen.md
filepath: elternleben/erziehung-und-foerderung/grenzen-setzen.md
title: Gewaltfrei Grenzen zeigen – Dr. Martina Stotz
url: https://www.elternleben.de/erziehung-und-foerderung/grenzen-setzen/
---

#  Gewaltfrei Grenzen setzen in fünf Schritten

In **fünf Schritten** zeigt dir Dr. Martina Stotz in diesem **Impuls-Video** ,
wie du deinem Kind **gewaltfrei deine innere Grenze** zeigen kannst.

[ ![](/fileadmin/_processed_/1/3/csm_Gewaltfrei_Grenzen_zeigen_-
_Impulse_von_Dr._Martina_Stotz_441a54dc8a.png)
](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))

