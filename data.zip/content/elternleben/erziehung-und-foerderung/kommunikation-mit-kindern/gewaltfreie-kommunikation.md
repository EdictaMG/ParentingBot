---
author: Kathy Weber
category:
- erziehung-und-foerderung
- kommunikation-mit-kindern
crawled_at: '2025-03-05T19:54:31.037111'
description: Kathy Weber stellt euch GFK (Gewaltfreie Kommunikation) nach Marshall
  B. Rosenberg vor. Kathy ist auf ElternLeben.de Expertin rund um Alltagskonflikte
  mit Kindern.
filename: gewaltfreie-kommunikation.md
filepath: elternleben/erziehung-und-foerderung/kommunikation-mit-kindern/gewaltfreie-kommunikation.md
title: Kathy Weber stellt GFK vor – Gewaltfreie Kommunikation
url: https://www.elternleben.de/erziehung-und-foerderung/kommunikation-mit-kindern/gewaltfreie-kommunikation/
---

#  Kathy Weber stellt 'GFK' vor – Gewaltfreie Kommunikation

Autorin - Kathy Weber

In diesem Video stellt Kathy Weber euch die ‚**Gewaltfreie Kommunikation** ‘
(GfK) nach Marshall B. Rosenberg vor. Kathy ist ausgebildete Trainerin der
Gewaltfreien Kommunikation, IHK zertifizierte Trainerin und
„**Giraffenträumerin** “ nach Frank Gaschler. Sie ist auf ElternLeben.de
Expertin rund um **Alltagskonflikte** mit Kindern im Familienleben.

[ ![](/fileadmin/_processed_/f/7/csm_Gewaltfreie_Kommunikation_-
_Kathy_Weber_stellt_GFK_vor_f7650cff3e.png) ](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))

