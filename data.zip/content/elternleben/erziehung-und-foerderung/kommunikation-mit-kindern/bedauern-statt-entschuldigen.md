---
author: Kathy Weber
category:
- erziehung-und-foerderung
- kommunikation-mit-kindern
crawled_at: '2025-03-05T20:15:08.089625'
description: Was bedeutet es sich zu entschuldigen? Gibt es einen Unterschied im Umgang
  miteinander, wenn man sich entschuldigt oder etwas bedauert?
filename: bedauern-statt-entschuldigen.md
filepath: elternleben/erziehung-und-foerderung/kommunikation-mit-kindern/bedauern-statt-entschuldigen.md
title: Bedauern statt entschuldigen – Kathy Weber
url: https://www.elternleben.de/erziehung-und-foerderung/kommunikation-mit-kindern/bedauern-statt-entschuldigen/
---

#  Bedauern statt entschuldigen – Kathy Weber

Autorin - Kathy Weber

Was bedeutet es, sich zu **ent-schuldigen**? Gibt es einen **Unterschied im
Umgang miteinander** , wenn man sich entschuldigt oder etwas **bedauert**?
Diese Fragen beantwortet Kathy Weber in diesem **Impuls-Video**.

[ ![](/fileadmin/_processed_/9/f/csm_Bedauern_statt_entschuldigen_-
_Impulse_von_Kathy_Weber_35be23910f.png) ](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))

