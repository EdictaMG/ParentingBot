---
author: ''
category:
- erziehung-und-foerderung
- krisen-und-konflikte
crawled_at: '2025-03-05T20:17:48.024491'
description: Wir beantworten Elternfragen! ElternLeben.de bietet Eltern eine kostenlose
  Online-Beratung, Tipps & Inhalte rund um das Elternleben.
filename: nach-dem-lockdown-mein-kind-verhaelt-sich-anders.md
filepath: elternleben/erziehung-und-foerderung/krisen-und-konflikte/nach-dem-lockdown-mein-kind-verhaelt-sich-anders.md
title: ElternLeben.de – Die Online-Plattform für Eltern
url: https://www.elternleben.de/erziehung-und-foerderung/krisen-und-konflikte/nach-dem-lockdown-mein-kind-verhaelt-sich-anders/
---

  1.   2.   3. 



#  Kostenlose Hebammensprechstunde

Du brauchst Rat zum Alltag mit deinem Baby?  
Unsere Hebamme Karin ist für dich da!

[ Per Telefon/ What's App ](/hebammensprechstunde/#c13582)

![](/fileadmin/Startseite/1_Elternwissen/3_Kleinkind/Video-Seminar-
Trennungsaengste-Martina_Stotz.jpg)

##  Kostenlose Elternsprechstunde

[ Termine finden ](/live/)

![ElternLeben.de Kind mit gelber
Mütze](/fileadmin/_processed_/c/7/csm_ElternLeben_Headerbild_13ec2c486e.jpg)

##  Alles für dein Elternleben

< < > >

##  Unsere ganze Expertise verständlich für dich aufbereitet

[ ![Schwangere Frau im rosa weißgepuntetem Kleid hält sich
Bauch.](/fileadmin/_processed_/3/e/csm_Artikel_Louwen_Dia__t_in_der_Schwangerschaft-
schmerza__rmere_Geburt_Kopie_881d62a31b.jpg) ](/schwangerschaft/)

[Schwangerschaft](https://www.elternleben.de/schwangerschaft/)

[ ![Fröhliches Baby liegt auf dem Rücken und
winkt.](/fileadmin/_processed_/c/3/csm_U__bersichtsseite_Slider_Baby_CANVA_klein_eb9a464331.jpg)
](/baby/)

[Baby](https://www.elternleben.de/baby/)

[ ![Junges Mädchen läuft fröhlich über
Sommerwiese](/fileadmin/_processed_/c/f/csm_Artikel_Resilienz_in_der_fru__hen_Kindheit-
Der_Grundstein_fu__r_eine_starke_Zukunft_Canva_klein_3a50d047d9.jpg)
](/kleinkind/)

[Kleinkind](https://www.elternleben.de/kleinkind/)

[ ![Schulkinder Junge und Mädchen lernen
zusammen](/fileadmin/_processed_/b/2/csm_Tipps_Pra__sentationen_in_der_Grundschule_richtig_vorbereiten_und_u__ben_41835ac6ff.jpg)
](/schulkind/)

[Schulkind](https://www.elternleben.de/schulkind/)

[ ![Liebenswerter Teenager: Mädchen lächelt in die
Kamera](/fileadmin/_processed_/a/0/csm_Artikel_Liebesnwerte_Teenager_Kopie_24062e522d.jpg)
](/teenager/)

[Teenager](https://www.elternleben.de/teenager/)

[ ![Kleines Mädchen und Mutter schauen sich an und haben
Spaß.](/fileadmin/_processed_/3/6/csm_Artikel_PREMIUM_Erziehungsstile_Pa__dagogische_Ansa__tze_fu__r_den_Eltern-
Alltag_shutterstock_603224183_KLEIN_576fd82218.jpg) ](/erziehung-und-
foerderung/)

[Erziehung und Förderung](https://www.elternleben.de/erziehung-und-
foerderung/)

[ ![Paar liegt auf dem Bett und hat einen
Lachanfall.](/fileadmin/_processed_/2/a/csm_Artikel_Humor_und_Lachen_in_der_Partnerschaft_iStock-156440653_Kopie_d7ef673ed6.jpg)
](/familie-und-partnerschaft/)

[Familie und Partnerschaft](https://www.elternleben.de/familie-und-
partnerschaft/)

[ ![Familie mit kleinen Kindern am
Esstisch](/fileadmin/_processed_/6/1/csm_Artikel_Stress_beim_Essen_12b9c4ef98.jpg)
](/gesundheit-ernaehrung/)

[Gesundheit und Ernährung](https://www.elternleben.de/gesundheit-ernaehrung/)



##  Kostenlose Beratung

Du benötigst zu einem speziellen Thema Hilfe und wünschst dir eine Beratung?
Unsere Expert*innen sind gern für dich da. Nutze unsere kostenlose Beratung
per **E-Mail** , in der **Online-Elternsprechstunde** oder in unserer
**telefonischen Hebammensprechstunde**.

[ zur Beratung ](/online-beratung-formate/)

**_"Ich bin so begeistert!! Karin ist ein Engel! Danke, dass diese Arbeit
kostenlos für uns Eltern ist. Es ist so viel Wert! Das hat mir Hoffnung und
ein Lichtblick für meine Situation gegeben. Eine super, kompetente und
hilfreiche Beratung."_**

Erfahrungsbericht

### [ Der Shop von ElternLeben.de  Entdecke unsere Online-Kurse, Video-
Seminare und Handbücher ](/shop/)

###  Du möchtest in einige Themen tiefer einsteigen? Schau mal in unsere
Video-Seminare

###  Das Bindungs-Seminar

[ ![](/fileadmin/_processed_/0/8/csm_Sichere_Bindung_zu_deinem_Baby_aufbauen_-
_Video-Seminar_von_ElternLeben.de_687b66698c.png)
](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))

Die erfahrene Familien- und Erziehungsberaterin Dr. Martina Stotz zeigt dir,
wie du Bindung in den verschiedenen Elternphasen aufbaust. Bindung während der
Schwangerschaft, nach der Geburt (Bonding), im Wochenbett und im 1. und
2.Lebensjahr.

[zum Bindung-Seminar](https://www.elternleben.de/shop/video-seminar-sichere-
bindung/)

###  Seminar gewaltfrei Grenzen zeigen

[

](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))

Schenke deinem Kind viel Sicherheit und Vertrauen durch bedürfnisorientierte
Grenzen. Und dir selbst das gute Gefühl, deine eigenen Grenzen ohne schlechtes
Gewissen zu vertreten!

[zum Seminar](https://www.elternleben.de/shop/video-seminar-gewaltfrei-
grenzen-zeigen/)

[Alle Seminare ansehen](https://www.elternleben.de/shop/)

![Grafik Newsletter
abonnieren](/fileadmin/_processed_/5/d/csm_NL_abonnieren_l_16167ec69f.jpg)

##  [Newsletter abonnieren](/newsletter-abonnieren/)

Abonniere den ElternLeben.de Newsletter und erhalte als Dank den wertvollen
**ElternLeben.de Bindungs-Leitfaden** mit praktischen **Tipps & Videos **zur
Stärkung eurer Eltern-Kind-Beziehung!

[ Newsletter abonnieren ](/newsletter-abonnieren/)

##  Neues auf ElternLeben.de

[ ![Logo ElternMail
Berlin](/fileadmin/_processed_/1/7/csm_Logo_ElternMail_RGB_Schutzraum_G_39fbe8d384.jpg)
News Berlin ElternMail Berlin ElternMail Berlin bietet Eltern in Berlin
Informationen rund um die vielen Herausforderungen des Familienlebens: Von den
ersten Lebensmonaten bis zum Ende der Schulzeit. ](/elternmail-berlin/)

[ ![Mutter stillt
Baby](/fileadmin/_processed_/e/9/csm_Q_A_X_HEADER_STILLEN_shutterstock_528384532_KLEIN_Kopie_01_71af36b820.jpg)
Ratgeber Alles rund ums Baby Erhalte wertvolle **Expertentipps für das erste
Jahr** mit deinem Baby. Von der Pflege bis zur Entwicklung - unser Ratgeber
begleitet dich durch die Babyzeit. ](/baby/)

[ ![Kleines Kind hält buntes Papierherz in die Kamera. Das Gesicht ist
verdeckt.](/fileadmin/_processed_/7/c/csm_Artikel_Medienschutz_fu__r_dein_Kind_im_Netz_-
_Tipps_fu__r_deinen_Alltag_iStock-1456451298_Kopie_eee505bbc5.jpg) Artikel
Medienschutz für dein Kind im Netz – Tipps für deinen Alltag Postest du gern
Bilder deines Kindes? Erfahre hier mehr darüber, warum du vorsichtig dabei
sein solltest, Fotos deines Kindes ins Netz zu stellen. ](/erziehung-und-
foerderung/medienkonsum-bei-kindern/medienschutz-im-netz/)

[ ![Frau macht
Yoga](/fileadmin/_processed_/2/f/csm_Schwangerschaft_Yoga_auf_Bett_sitzen_cut_cf0b9a1ae8.jpg)
Beratung Telefonische Hebammensprechstunde Hast du eine Frage an einer
Hebamme?  
Du bist schwanger und brauchst Rat? Unsere Hebammen sind für dich da!
](/hebammensprechstunde/)

[ ![Von hinten zu sehen. Zwei Männer umarmen sich und haben Jungen auf der
Schulter.](/fileadmin/_processed_/0/b/csm_Interview_Regenbogenfamilie-
Zu_wem_von_Ihnen_sagt_das_Kind_dann_Mama_Bjoern_und_Christian-
papaundpapi_2_4e66300bfe.jpg) Interview Regenbogenfamilie – Zu wem von Ihnen
sagt das Kind dann Mama? Eine ganz normale Regenbogenfamilie – das sind Bjoern
und Christian mit ihrem Sohn Lukas. Im Interview erzählen sie uns, welchen
aufreibenden, lehrreichen und spannenden Weg sie gegangen sind und noch gehen.
](/familie-und-partnerschaft/regenbogenfamilie-zu-wem-von-ihnen-sagt-das-kind-
dann-mama/)

[ ![Traurige Frau sitzt mit Kopf am Fenster gelehnt und sieht durch
Fensterscheibe mit
Regntropfen.](/fileadmin/_processed_/5/6/csm_Artikel_Fehlgeburt_iStock-1418507601_2b9b7b8c06.jpg)
Artikel Fehlgeburt: Expertenratschläge für deine körperliche und seelische
Gesundheit Erhalte hier wertvolle Hinweise zu Ursachen, Symptomen und
Behandlungsmöglichkeiten von Fehlgeburten.
](/schwangerschaft/geburt/fehlgeburt/)

##  Triff unsere Expert*innen in verschiedenen kostenfreien Beratungsformaten

##  E-Mail-Beratung

[

](/ueber-stell-uns-deine-frage/)

Stelle deine Frage über unser Online-Formular.  
Du bekommst eine Antwort von unseren Expert*innen innerhalb von maximal 36
Stunden  
(48 Std. an Wochenend- und Feiertagen).

[Weiter zur E-Mail-Beratung](https://www.elternleben.de/ueber-stell-uns-deine-
frage/)

##  Elternsprechstunde (online)

[ ![](/fileadmin/_processed_/1/7/csm_Live-
Seminar_Trennungsa__ngste_Dr._Martina_Stotz_22.10.20_01103dd2d7.jpg)
](/elternsprechstunde/)

Egal welches Thema dich gerade beschäftigt, egal wie alt dein Kind ist –
unsere Expertinnen**** beantworten in regelmäßigen Themen-Sprechstunden deine
Fragen.

[Zur Elternsprechstunde](https://www.elternleben.de/elternsprechstunde/)

##  Telefonische Hebammensprechstunde



Hast du eine Frage an eine Hebamme?  
Ob Stillen, Schlafen, Weinen, Beikost, oder andere Themen: Unsere Hebamme
Karin ist für dich da!

[Weiter zur
Hebammensprechstunde](https://www.elternleben.de/hebammensprechstunde/)

##  Das Expert*innen-Team

![Dr. Martina
Stotz](/fileadmin/_processed_/7/1/csm_Dr._Martina_Stotz_sq_663ac62b94.jpeg)

Dr. Martina Stotz

Fachliche Leitung  
Familien- Erziehungs- und Paarberaterin

![Karin Hackbarth](/fileadmin/_processed_/2/9/csm_Karin-
Hackbarth_52d03789ab.jpg)

Karin Hackbarth

Hebamme und Babyschlaf-Expertin

![Renate
Lieberknecht](/fileadmin/_processed_/7/3/csm_Renate_Lieberknecht_5f4584b88b.png)

Renate Lieberknecht

Expertin rund um das Thema Ernährung

![Heiner
Fischer](/fileadmin/_processed_/5/f/csm_Heiner_Fischer_Experte_ElternLeben_KLEIN_7efc606a8a.jpg)

Heiner Fischer

Aktive Vaterschaft und Vereinbarkeit von Familie und Beruf

[Großes Expert*innen-Team kennenlernen](https://www.elternleben.de/ueber-
uns/experten/)

##  Angebote vor Ort: Elternleben-Angebote in deiner Nähe

Du suchst kompetente Unterstützung vor Ort oder möchtest dich mit anderen
Menschen austauschen?  
In unserer deutschlandweiten Datenbank findest du wertvolle, lokale Angebote:
Hebammen, Kinderarzt*innen, Einrichtungen für Familien, Berater*innen und
vieles mehr.

Über Einrichtungen, die in unser Verzeichnis aufgenommen werden möchten,
freuen wir uns. [Mehr Infos dazu.](https://www.elternleben.de/angebote-vor-
ort-informationen/)

Angebot finden

![Grafik. Rotes Herz in der Mitte eines
Stadtplans.](/fileadmin/Startseite/Angebote_vor_Ort_Landkarte_Herz.png)

![ElternLeben.de-Teamphoto](/fileadmin/_processed_/9/9/csm_EL-
Team_aa8b243fdf.jpg)

![Bücherregal mit
Kopfform](/fileadmin/_processed_/d/3/csm_Das_Expertenteam_iStock_72165023_small_dac537bb1f.jpeg)

![Logo wellcome gGmbH](/fileadmin/_processed_/e/7/csm_wellcome-
logo_l_817d64c5bb.jpg)

  * ### Über uns

ElternLeben.de möchte Mütter und Väter in jeder Elternphase entlasten und
begleiten. Durch zahlreiche Formate bieten wir Eltern die Möglichkeit, sich
sicher im Umgang mit ihren Kindern zu fühlen und ihr Elternleben mit
Gelassenheit und Lebensfreude zu leben.
**[Weiterlesen](https://www.elternleben.de/ueber-uns/)**

  * ### Team und Expert*innen

**[Unsere Expert*innen](https://www.elternleben.de/ueber-uns/experten/)**
begleiten dich mit viel Herz, Expertise und all ihren praktischen Erfahrungen.
**[Unser Team](https://www.elternleben.de/ueber-uns/team/)** sorgt dafür, dass
Inhalte fachlich fundiert und Formate für Eltern leicht anwendbar und
auffindbar sind.

  * ### Die wellcome gGmbH

wellcome will mit seiner unmittelbaren Unterstützung Eltern entlasten, beraten
und vernetzen, damit Kinder in einer liebevollen Umgebung gesund aufwachsen
können. Wir entwickeln Angebote für alle Familien – ganz unabhängig vom
sozialen Hintergrund. **[www.wellcome-online.de](https://www.wellcome-
online.de)**

##  Noch weitere Fragen?

![Berit
Lohnzweiger](/fileadmin/_processed_/d/3/csm_Berit_Lohnzweiger_71b9795859.jpg)

Berit Lohnzweiger

Leitung Marketing und Kommunikation

0176 470 779 82

[ berit.lohnzweiger@elternleben.de
](javascript:linkTo_UnCryptMailto\(%27nbjmup%2Bcfsju%5C%2FmpioaxfjhfsAfmufsomfcfo%5C%2Fef%27\);)

[Für Unternehmen](https://www.elternleben.de/kooperationen/)

