---
author: ''
category:
- baby
- babyschlaf
crawled_at: '2025-03-05T20:34:59.264843'
description: 'Baby im Bett, ja oder nein? Da gehen die Meinungen auseinander: Kirsten
  von Mejer und Katrin Gensheimer geben Pro und Contra.'
filename: baby-im-bett.md
filepath: elternleben/baby/babyschlaf/baby-im-bett.md
title: Soll man das Baby im Bett schlafen lassen?
url: https://www.elternleben.de/baby/babyschlaf/baby-im-bett/
---

#  Baby im Bett?

Das Spannende am Abenteuer Familie ist, dass es für viele Entscheidungen
keinen festen Kompass, kein Schwarz- oder Weißbuch gibt, sondern dass Mütter
und Väter immer wieder danach fragen müssen, was für sie, ihre spezifische
Lebenssituation und für den Charakter oder das Temperament ihres Kindes am
besten ist. Weil manchmal andere Meinungen helfen, um den eigenen Weg zu
finden, stellen wir euch zu wichtigen Elternthemen unterschiedliche
Standpunkte dar.

Lesezeit: Etwa **2 Minuten**

![Kuscheltier Teddy-Bär im Bett](/fileadmin/_processed_/d/4/csm_pro_u_con-
Baby_im_Bett_8e7ebfe1f5.jpg)



##  Kirsten von Mejer: "hier bin ich schon"

**Kirsten von Mejer, Kommunikationscoachin. "Ich bin doch auch noch ICH und
nicht nur Mutter."**  
  
Da war sie nun – warm und weich und lecker riechend. Unsere Tochter. Und ja,
da war sie nun, hungrig und fordernd, den ganzen Tag an mir dran und um mich
herum. Ich meine, den ganzen Tag, jeden Tag, 24 Stunden lang, immerzu.  
Das war zu viel. Deutlich. Ich war doch noch immer irgendwo ICH und nicht nur
Mutter, oder? Dieser Kampf tobte in mir. Jeden Tag – aber nie in der der Nacht
– da war alles gut, sie bei uns im Bett, so nah, suchend und uns immer findend
und wir waren einfach da.  
Sie hat jetzt schon lange ihr eigenes Bett und schläft dort gerne ein. Und wir
alle freuen uns, wenn die Dame irgendwann taps-taps-taps zu uns kommt „hier
bin ich schon“ und wir den Rest der Nacht gemeinsam verbringen, nah und alle
sind einfach da.



##  Katrin Gensheimer: "Wo bleibt die romantische Zweisamkeit?"

**Katrin Gensheimer hat es erfolgreich geschafft, ihre zwei lebhaften Jungs in
ihren eigenen Betten nächtigen zu lassen. So freut sie sich immer auf das
Wochenende, wenn ihre Männer morgens angewackelt kommen und sich dann nochmal
an sie kuscheln.**  
  
Ich bin in manchen Dingen ein freiheitsliebender Mensch. Dazu gehört, dass
mein Bett mir gehört. Zumindest meine Hälfte. Ich kann einfach nicht gut
schlafen, wenn andere, vor allem kleine, empfindliche Wesen mir meinen Platz
im Bett streitig machen. Außerdem hatte ich immer Bedenken, dass es meinen
Jungs zu warm würde, wenn sie zu eng bei mir lagen oder sogar noch von meiner
Decke zusätzlich zugedeckt wurden.  
Ganz schrecklich fand ich die Vorstellung, dass sich meine Kinder an mein Bett
gewöhnen und gar nicht mehr in ihrem eigenen Bett schlafen wollen. Wie soll
ich mich erholen, wenn ich nächtlichen Besuch habe, der sich ständig bewegt,
Geräusche von sich gibt und mir zudem noch meine Bettdecke wegnimmt?!  
Schließlich wollte ich tagsüber fit sein, um der Rasselbande und meinem Job
gerecht werden zu können.  
Und: Wo bleibt die romantische Zweisamkeit, wenn kleine Racker im Raum
anwesend sind?

