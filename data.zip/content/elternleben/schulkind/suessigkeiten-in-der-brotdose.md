---
author: ''
category:
- schulkind
crawled_at: '2025-03-05T19:45:01.321669'
description: Süßes in der Brotdose? Ob Eltern ihren Kindern Süßigkeiten in ihre Frühstücksdose
  mitgeben sollen - darüber gibt es viel Streit beim Elternabend. Hannah Löwe im Vlog
filename: suessigkeiten-in-der-brotdose.md
filepath: elternleben/schulkind/suessigkeiten-in-der-brotdose.md
title: 'Hannah Löwe: Süßigkeiten in der Frühstücksdose?'
url: https://www.elternleben.de/schulkind/suessigkeiten-in-der-brotdose/
---

#  Süßigkeiten in der Frühstücksdose?

Ob Süßes in den Brotdosen unserer Kinder sein darf oder nicht, ist ein ewiges
Streitthema unter Eltern. Auf Elternabenden oder Elternstammtischen in der
Grundschule gibt es heftige Auseinandersetzungen darüber. Die einen sagen, es
darf niemals Süßes in die Frühstücksdose, andere wollen nur an bestimmten
Tagen oder einmal im Monat etwas Süßes mitgeben. Viele Eltern wollen eine ganz
klare Regelung von Anfang an.

Mehr von Hannah Löwe findet ihr in ihrem [Youtube-
Channel](https://www.youtube.com/channel/UC-150_R5aEyxKB96PWqACHA).

[ ![](/fileadmin/_processed_/7/f/csm_Suessigkeiten_in_den_Kinder-
Brotdosen__537b7abd58.png) ](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))

