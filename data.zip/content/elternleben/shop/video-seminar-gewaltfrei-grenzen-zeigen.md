---
author: ''
category:
- shop
crawled_at: '2025-03-05T20:29:54.143736'
description: In diesem Video-Seminar lernen Mütter und Väter, wie sie ihrem Kind gewaltfrei
  Grenzen zeigen können und ihre Kinder durch liebevolle Führung stärken.
filename: video-seminar-gewaltfrei-grenzen-zeigen.md
filepath: elternleben/shop/video-seminar-gewaltfrei-grenzen-zeigen.md
title: Video-Seminar Gewaltfrei Grenzen zeigen
url: https://www.elternleben.de/shop/video-seminar-gewaltfrei-grenzen-zeigen/
---

  1. [ Home ](/)
  2. [ Shop ](/shop)
  3. Gewaltfrei Grenzen zeigen

#  Video-Seminar: Gewaltfrei Grenzen zeigen

![](/fileadmin/_processed_/4/e/csm_Produktbilder-VS-Gewaltfrei_Grenzen_zeigen-
Slider-1_2c5c7887a9.jpg) ![](/fileadmin/_processed_/9/f/csm_Produktbilder-VS-
Gewaltfrei_Grenzen_zeigen-Slider-2_77f27804c1.jpg)
![](/fileadmin/_processed_/8/1/csm_Produktbilder-VS-Gewaltfrei_Grenzen_zeigen-
Slider-3_edf59b6506.jpg) ![](/fileadmin/_processed_/5/a/csm_Produktbilder-VS-
Gewaltfrei_Grenzen_zeigen-Slider-4_1fb03cdc87.jpg)
![](/fileadmin/_processed_/e/5/csm_Produktbilder-VS-Resilienz-
Slider-5_705272e1ad.jpg)

![](/fileadmin/_processed_/4/e/csm_Produktbilder-VS-Gewaltfrei_Grenzen_zeigen-
Slider-1_543829cd83.jpg)

![](/fileadmin/_processed_/9/f/csm_Produktbilder-VS-Gewaltfrei_Grenzen_zeigen-
Slider-2_0e6f84bde0.jpg)

![](/fileadmin/_processed_/8/1/csm_Produktbilder-VS-Gewaltfrei_Grenzen_zeigen-
Slider-3_ca0f7ece37.jpg)

![](/fileadmin/_processed_/5/a/csm_Produktbilder-VS-Gewaltfrei_Grenzen_zeigen-
Slider-4_2e2db37266.jpg)

![](/fileadmin/_processed_/e/5/csm_Produktbilder-VS-Resilienz-
Slider-5_a20ee4db57.jpg)

  * 10 kompakte Videos mit Tanja: insgesamt ca. 1:30 Std.
  * unbegrenzten Zugriff = volle Flexibilität
  * inkl. Podcast-Version (Audio only) und Workbook

34,90 €

[jetzt kaufen](https://shop.elternleben.de/s/elternleben/video-seminar-
gewaltfrei-grenzen-zeigen/payment)

**Dein Kind haut, wirft mit Essen oder der Medienkonsum findet kein Ende?** In
vielen Situationen müssen wir unseren Kindern Grenzen setzen – oft eskaliert
die Lage und wir sind mitten im Machtkampf. So geht es unzähligen Eltern. Das
Gute: Es gibt einen anderen Weg!

Im Video-Seminar erhältst du die Sicherheit, deinem Kind wichtige Grenzen
aufzuzeigen und die Grenzen deiner Kinder dabei zu respektieren und zu
schützen.

##  Das erwartet dich

[

](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))

Unsere Expertin Tanja Bolhuis-Fisser vermittelt dir an vielen praktischen
Beispielen, welche Art von Grenzen dein Kind unbedingt braucht und wie du sie
liebevoll und verlässlich aufzeigen kannst.

Schenke deinem Kind viel Sicherheit und Vertrauen durch bedürfnisorientierte
Grenzen. Und dir selbst das gute Gefühl, deine eigenen Grenzen ohne schlechtes
Gewissen zu vertreten!

##  Das lernst du im Video-Seminar

  * Weshalb Kinder überhaupt Grenzen brauchen
  * Wie sich Machtausübung von liebevoller Führung unterscheidet
  * Warum es uns oft schwerfällt, Grenzen zu setzen
  * Warum Gleichberechtigung nicht funktioniert
  * Wie sich Wünsche von Bedürfnissen unterscheiden

**_„Nur wenn wir unsere Grenzen klar kommunizieren erfahren Kinder, dass auch
sie Grenzen haben und sich positionieren können."_**

Expertin Tanja Bolhuis-Fisser

## Du erhältst  
  
---  
 unbegrenzten Zugriff  
 10 kompakte Videos mit Tanja:
insgesamt ca. 1,5 Std.  
 zahlreiche Übungen zur Wahrung
DEINER Grenzen  
 Podcast-Version (Audio only)  
 Workbook**** zum Ausdrucken  
34,90 €  
[ Jetzt kaufen ](https://shop.elternleben.de/s/elternleben/video-seminar-
gewaltfrei-grenzen-zeigen/payment)  
  
##  Bewertungen

**Sterne aus Bewertungen**

**Weiterempfehlungen**

![Icon graue
Anfuehrungsstriche](/fileadmin/Assets/Icons/anfuehrungsstriche_grau.svg)

![Icon graue
Anfuehrungsstriche](/fileadmin/Assets/Icons/anfuehrungsstriche_grau.svg)

##  Blick ins Video-Seminar

Inhalt  
---  
Willkommen!  
🎬 Das erwartet dich  
🎬 1\. Warum Kinder Grenzen brauchen  
🎬 2\. Wie Grenzen Bedürfnisse erfüllen  
🎬 3\. Deine innere Haltung reflektieren  
🎬 4\. Drei Schritte zu deiner klaren Haltung  
🎬 5\. Die Grenzen unserer Kinder wahren  |  Preview anzeigen  
[ ![5. Die Grenzen unserer Kinder
wahren](https://img.youtube.com/vi/TVeX4_8EvdQ/maxresdefault.jpg)
](javascript:Cookiebot.renew\(\)) [Bitte _akzeptieren Sie Marketing-Cookies_ ,
um diesen Inhalt anzuzeigen.](javascript:Cookiebot.renew\(\))  
🎬 6\. Unterschied zwischen Machtausübung und liebevoller Führung  
🎬 7\. Vier Ebenen um bedürfnisorientiert Grenzen aufzuzeigen  
🎬 8\. Alltagshelfer beim Grenzen zeigen  
🎬 9\. Zusammenfassung  
🔊 Als Podcast (Audio only)  
  
[ Jetzt kaufen ](https://shop.elternleben.de/s/elternleben/video-seminar-
gewaltfrei-grenzen-zeigen/payment)

##  Tanja Bolhuis-Fisser teilt ihr Wissen und ihre Erfahrung



Tanja Bolhuis-Fisser

Online-Beratung

Tanja Bolhuis-Fisser ist auf ElternLeben.de Expertin für **ganzheitliche
Familienberatung**. Dabei richtet sie ihre Arbeit **beziehungs- und
bedürfnisorientiert** aus. Sie berät in unserer Online-Beratung und führt
durch unser Video-Seminar ‚Bedürfnisorientiert Grenzen aufzeigen‘.  
  
Sie ist staatlich anerkannte Erzieherin und seit 2020 selbständig in der
ganzheitlichen Familienberatung tätig. Parallel ist sie in der Ausbildung zur
systemischen Familienberaterin. Sie hat viele Jahre umfassende Erfahrungen in
Kindertagesstätten und in einem Familienzentrum im Elementarbereich sammeln
können.  
  
Tanja Bolhuis-Fisser konnte durch freie Projekte in Brennpunkten wertvolle
Erfahrungen in der stationären Jugendhilfe machen. Nach erfolgreichem
Abschluss als Erzieherin war es ihr Wunsch, in diesem Bereich Fuß zu fassen
und begleitete Jugendliche und junge Erwachsene, in enger Zusammenarbeit mit
den Eltern, auf ihrem Weg aus der Krise.  
  
Einige Jahre später übernahm Tanja Bolhuis-Fisser die Leitung einer intensiv-
pädagogisch-therapeutischen Kleinsteinrichtung für junge Erwachsene, bis zu
ihrer Schwangerschaft. Während ihrer Elternzeit begann sie die Ausbildung zur
Heilpraktikerin für Psychotherapie, dessen Abschluss noch aussteht.
Regelmäßige Einzel/Team- sowie Fallsupervisionen ergänzen ihr stetiges Ziel
der Verbesserung ihrer fachlichen Kompetenzen. Tanja Bolhuis-Fisser lebt mit
ihrer Familie in Ostfriesland.

##  Alle Video-Seminare auch in der App von ElternLeben.de

**Hole dir nach dem Kauf die ElternLeben.de-App** für Offline-Zugriff auf alle
Lektionen, Erinnerungen für  
kostenfreie Live-Events und exklusive Rabatte auf neue eBooks und Video-
Seminare.

[ 
](https://play.google.com/store/apps/details?id=com.elternleben.app)

[ 
](https://apps.apple.com/app/id1611753266)

Dieses Video-Seminar wurde gefördert durch:



