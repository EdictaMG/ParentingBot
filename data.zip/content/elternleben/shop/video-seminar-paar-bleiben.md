---
author: ''
category:
- shop
crawled_at: '2025-03-05T20:26:43.177703'
description: Im Still-Seminar mit Hebamme Karin erfahren Eltern alles über das Stillen.
  Vom ersten Anlegen über verschiedene Stillhaltungen, einen Stillrhythmus, die Pflege
  der Brustwarzen und das Abstillen bis hin zu Alternativen, wenn es mit dem Stillen
  nicht klappt.
filename: video-seminar-paar-bleiben.md
filepath: elternleben/shop/video-seminar-paar-bleiben.md
title: Video-Seminar Paar bleiben
url: https://www.elternleben.de/shop/video-seminar-paar-bleiben/
---

  1. [ Home ](/)
  2. [ Shop ](/shop)
  3. Video-Seminar Eltern sein – Liebespaar bleiben

#  Video-Seminar: Eltern sein, Liebespaar bleiben

![](/fileadmin/_processed_/9/a/csm_Produktbilder-VS-Paarbeziehung-
Slider-1_993d1906ee.jpg) ![](/fileadmin/_processed_/5/7/csm_Produktbilder-VS-
Paarbeziehung-Slider-2_39d3880e07.jpg)
![](/fileadmin/_processed_/e/2/csm_Produktbilder-VS-Paarbeziehung-
Slider-3_5664208a29.jpg) ![](/fileadmin/_processed_/2/0/csm_Produktbilder-VS-
Paarbeziehung-Slider-4_787cbcf632.jpg)
![](/fileadmin/_processed_/8/f/csm_Produktbilder-VS-Paarbeziehung-
Slider-5_eac97145ba.jpg)

![](/fileadmin/_processed_/9/a/csm_Produktbilder-VS-Paarbeziehung-
Slider-1_341c4c89b3.jpg)

![](/fileadmin/_processed_/5/7/csm_Produktbilder-VS-Paarbeziehung-
Slider-2_7a63e22de3.jpg)

![](/fileadmin/_processed_/e/2/csm_Produktbilder-VS-Paarbeziehung-
Slider-3_eacfa2e01d.jpg)

![](/fileadmin/_processed_/2/0/csm_Produktbilder-VS-Paarbeziehung-
Slider-4_71cfdb2857.jpg)

![](/fileadmin/_processed_/8/f/csm_Produktbilder-VS-Paarbeziehung-
Slider-5_9192030a76.jpg)

  * 10 kompakte Videos mit Martina: insgesamt ca. 2 Std.
  * unbegrenzten Zugriff = volle Flexibilität
  * inkl. Podcast-Version (Audio only) und Workbook

34,90 €

[jetzt kaufen](https://shop.elternleben.de/s/elternleben/video-seminar-paar-
bleiben/payment)

Fühlt ihr euch auch oft wie „Elternroboter“, streitet viel und fragt euch, wo
ihr als PAAR geblieben seid? Die Elternrolle zu erfüllen und gleichzeitig ein
Liebespaar zu bleiben, stellt viele Mütter und Väter vor große
Herausforderungen.

**Elternschaft = Beziehungskiller? Muss nicht so sein!** Im Video-Seminar
erfahrt ihr, wie ihr mit wenig Zeitaufwand eure Liebe als Paar, trotz
Familienalltag, erneut zum Fliegen bringt!

##  Das erwartet dich

[ ![](/fileadmin/_processed_/4/e/csm_Video_Seminar_Eltern_sein_-
_Liebespaar_bleiben_von_ElternLeben.de_2930225497.png)
](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))

Die erfahrene Familien- und Paarberaterin Dr. Martina Stotz zeigt euch, wie
ihr ein gutes Beziehungsvorbild für eure Kinder seid. Ihr lernt, konstruktiv
zu streiten und im Alltag liebevoller und entspannter miteinander umzugehen.

##  Das lernt ihr im Video-Seminar Eltern sein – Liebespaar bleiben

  * Wie ihr eigene Gefühle und Bedürfnisse und die des Partners/Partnerin erkennt.
  * Wie ihr gemeinsame Familienwerte definiert.
  * Welchen Umgang es mit verschiedenen Erziehungsvorstellungen gibt.
  * Wie ihr euch gegenseitige Wertschätzung schenkt.
  * Wie ihr im Alltag als Liebespaar verbunden bleibt.

**_„Manchmal sprechen Paare verschiedene Sprachen der Liebe – daher ist
gegenseitige Wertschätzung in jeder Paarbeziehung essentiell."_**

Dr. Martina Stotz

## Du erhältst  
  
---  
 unbegrenzten Zugriff  
 10 kompakte Videos mit Martina:
insgesamt ca. 2 Std.  
 verschiedene Übungen zum
Reflektieren  
 Podcast-Version (Audio only)  
 Workbook**** zum Ausdrucken  
34,90 €  
[ Jetzt kaufen ](https://shop.elternleben.de/s/elternleben/video-seminar-paar-
bleiben/payment)  
  
##  Blick ins Video-Seminar

Inhalt  
---  
Willkommen!  
🎬 Das erwartet dich  
🎬 1\. Wo steht ihr in eurer Paarbeziehung?  |  Preview anzeigen  
[ ![1. Wo steht ihr in eurer
Paarbeziehung?](https://img.youtube.com/vi/uNBg6PeJNQk/maxresdefault.jpg)
](javascript:Cookiebot.renew\(\)) [Bitte _akzeptieren Sie Marketing-Cookies_ ,
um diesen Inhalt anzuzeigen.](javascript:Cookiebot.renew\(\))  
🎬 2\. Prägungen aus der Herkunftsfamilie erkennen  
🎬 3\. Umgang mit unterschiedlichen Erziehungsvorstellungen  
🎬 4\. Umgang mit Streit in der Partnerschaft  
🎬 5\. Gefühle und Bedürfnisse in der Paarbeziehung  
🎬 6\. Gegenseitige Wertschätzung schenken  
🎬 7\. Alltagstipps für mehr Verbindung im Alltag  
🎬 8\. Zusammenfassung  
🎬 9\. Danke und mehr zum Angebot von ElternLeben.de  
🔊 Als Podcast (Audio only)  
  
[ Jetzt kaufen ](https://shop.elternleben.de/s/elternleben/video-seminar-paar-
bleiben/payment)

##  Dr. Martina Stotz teilt ihr Wissen und ihre Erfahrung

![Martina
Stotz](/fileadmin/_processed_/2/4/csm_Dr._Martina_Stotz_NAH_neu_90a21d79e3.jpeg)

Dr. Martina Stotz

Fachliche Leitung & Online-Beratung

Dr. Martina Stotz ist auf ElternLeben.de verantwortlich für alle fachlichen
Inhalte und leitet das Expert*innenteam sowie die Onlineberatung.  
Als Doktorin der Pädagogik (5 Jahre Forschung im Bereich der Familien- und
Entwicklungspsychologie an der LMU in Müchen) und Familien- Erziehungs- und
Paarberaterin begleitet sie Eltern und Kinder bereits seit vielen Jahren. Sie
war 7 Jahre Lehrerin, sowie Schulberaterin in der Grund- und Mittelschule.
Zahlreiche Erfahrungen hat sie auch mit Krippen- und KiTa-Kindern durch ihre
Arbeit in der musikalischen Früherziehung.  
  
Ihre Vision ist es, so viele Eltern wie möglich kompetent und einfühlsam zu
begleiten, damit sie Selbstsicherheit und Vertrauen in ihre eigenen
Fähigkeiten entwickeln und Kinder darüber Liebe, Geborgenheit und Leichtigkeit
erfahren.

##  Alle Video-Seminare auch in der App von ElternLeben.de

**Hole dir nach dem Kauf die ElternLeben.de-App** für Offline-Zugriff auf alle
Lektionen, Erinnerungen für  
kostenfreie Live-Events und exklusive Rabatte auf neue eBooks und Video-
Seminare.

[ 
](https://play.google.com/store/apps/details?id=com.elternleben.app)

[ 
](https://apps.apple.com/app/id1611753266)

Dieses Video-Seminar wurde gefördert durch:



