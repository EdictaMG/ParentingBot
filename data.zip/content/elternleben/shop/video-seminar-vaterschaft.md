---
author: ''
category:
- shop
crawled_at: '2025-03-05T20:35:16.983774'
description: Was aktive Vaterschaft bedeutet, wie du deine Potentiale als Vater entfaltest
  und in die praktische Umsetzung kommst, erfährst du in diesem Video-Seminar mit
  Heiner Fischer.
filename: video-seminar-vaterschaft.md
filepath: elternleben/shop/video-seminar-vaterschaft.md
title: Video-Seminar Vaterschaft
url: https://www.elternleben.de/shop/video-seminar-vaterschaft/
---

  1. [ Home ](/)
  2. [ Shop ](/shop)
  3. Video-Seminar Aktive Vaterschaft

#  Video-Seminar: Aktive Vaterschaft

![](/fileadmin/_processed_/8/2/csm_Produktbilder-VS-Aktive_Vaterschaft-
Slider-1_8f6411f984.jpg) ![](/fileadmin/_processed_/f/a/csm_Produktbilder-VS-
Aktive_Vaterschaft-Slider-2_1ed5ad0a01.jpg)
![](/fileadmin/_processed_/a/b/csm_Produktbilder-VS-Aktive_Vaterschaft-
Slider-3_d9aa98c758.jpg) ![](/fileadmin/_processed_/d/5/csm_Produktbilder-VS-
Aktive_Vaterschaft-Slider-4_2693abaa05.jpg)
![](/fileadmin/_processed_/c/e/csm_Produktbilder-VS-Aktive_Vaterschaft-
Slider-5_4ca23b94ec.jpg)

![](/fileadmin/_processed_/8/2/csm_Produktbilder-VS-Aktive_Vaterschaft-
Slider-1_9f38269234.jpg)

![](/fileadmin/_processed_/f/a/csm_Produktbilder-VS-Aktive_Vaterschaft-
Slider-2_ff7c25efd9.jpg)

![](/fileadmin/_processed_/a/b/csm_Produktbilder-VS-Aktive_Vaterschaft-
Slider-3_fb057e3eba.jpg)

![](/fileadmin/_processed_/d/5/csm_Produktbilder-VS-Aktive_Vaterschaft-
Slider-4_fe33bcb5fd.jpg)

![](/fileadmin/_processed_/c/e/csm_Produktbilder-VS-Aktive_Vaterschaft-
Slider-5_2612b3f33f.jpg)

  * 10 kompakte Videos mit Heiner: insgesamt ca. 2 Std.
  * unbegrenzten Zugriff = volle Flexibilität
  * inkl. Podcast-Version (Audio only) und Workbook

34,90 €

[jetzt kaufen](https://www.elternleben.de/shop/video-seminar-
vaterschaft/payment/)

**Bist du den Anforderungen an die heutigen Väter gewachsen?**

Du bist unsicher und weißt nicht was es braucht, um eine aktive Vaterrolle zu
leben – auf Augenhöhe mit deiner/deinem Partner*in zu sein?

**Selbstsicher als aktiver Vater!** Im Video-Seminar erfährst du, wie du eine
enge Bindung und Beziehung zu deinem Kind aufbaust – von Anfang an!

##  Das erwartet dich

[ ![](/fileadmin/_processed_/4/9/csm_Video-
Seminar__Aktive_Vaterschaft_erfolgreich_gestalten__von_ElternLeben_de_88f7f8d59b.png)
](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))

Der erfahrene Sozialpädagoge M.A. und Systemische Berater, Heiner Fischer
zeigt dir, wie du deine väterlichen Potentiale aktivierst und umsetzt, damit
ihr als Eltern gleichwertig an einem Strang zieht.

##  Das lernst du im Video-Seminar Aktive Vaterschaft erfolgreich gestalten

  * Was die Gesellschaft unter ‚Männlichkeit‘ versteht und welche Glaubenssätze du über Bord wirfst.
  * Wie du dein eigenes Vaterbild gestaltest und deine Vatervision entwickelst.
  * Was typische Strategien von Männern in Krisen sind.
  * Wie du deine Stärken und Potentiale als Vater erkennst, ausbaust und umsetzt.
  * Welche Strategien du als aktiver Vater im Alltag mit deinem Kind lebst.

**_„Aktive Väter helfen nicht! Sie übernehmen ihren Teil der Verantwortung in
der Familie und wollen dabei keine bessere Mutter sein!"_**

Heiner Fischer

[ Jetzt kaufen ](/shop/video-seminar-vaterschaft/payment/)

## Du erhältst  
  
---  
 unbegrenzten Zugriff  
 10 kompakte Videos mit Heiner:
insgesamt ca. 2 Std.  
 Übungen zum Reflektieren  
 Podcast-Version (Audio only)  
 Material für direkte Umsetzung
im Downloadbereich  
 Workbook zum Ausdrucken  
34,90 €  
[ Jetzt kaufen ](/shop/video-seminar-vaterschaft/payment/)  
  
**[ElternLeben.de ist gemeinnützig.](https://www.elternleben.de/ueber-uns/)**

Damit wir alle Eltern mit unseren Produkten unterstützen können, bieten wir
Ermäßigungen. Falls du dir die Teilnahme nicht leisten kannst, schreibe uns
eine E-Mail an info[at]elternleben.de

##  Blick ins Video-Seminar

Inhalt  
---  
Willkommen!  
🎬 Das erwartet dich  
🎬 1\. Anforderungen an die heutigen Väter  |  Preview anzeigen  
[ ![1. Anforderungen an die heutigen
Väter](https://img.youtube.com/vi/iTp1Nwra-Po/maxresdefault.jpg)
](javascript:Cookiebot.renew\(\)) [Bitte _akzeptieren Sie Marketing-Cookies_ ,
um diesen Inhalt anzuzeigen.](javascript:Cookiebot.renew\(\))  
🎬 2\. Krisen begegnen uns in jeder Lebensphase  
🎬 3.1. Typische Strategien von Männern in Krisen  
🎬 3.2. Vaterwerden als Orientierungskrise  
🎬 4\. Die eigene Vatervision entwickeln  
🎬 5\. Väterliche Potenziale entfalten  
🎬 6\. Als Eltern an einem Strang ziehen  
🎬 7\. Alles unter einen Hut bekommen  
🎬 8\. Zusammenfassung und Danke  
🔊 Als Podcast (Audio only)  
  
##  Heiner Fischer teilt sein Wissen und seine Erfahrung

![Heiner
Fischer](/fileadmin/_processed_/5/f/csm_Heiner_Fischer_Experte_ElternLeben_KLEIN_876e7320e8.jpg)

Heiner Fischer

Online-Beratung

Heiner Fischer ist auf ElternLeben.de Experte rund um das Thema **Aktive
Vaterschaft** und **Vereinbarkeit von Familie und Beruf**. In der Online-
Beratung nimmt er sich den Fragen zu seinen Themenschwerpunkten an.  
  
Der Vater von zwei Kindern *2016 und *2018 ist fest davon überzeugt, dass
Vaterschaft mehr ist als für das Familieneinkommen zu sorgen oder der
Spielplatzheld zu sein.

Er ist gelernter Medienberater, Sozialpädagoge mit Zusatzausbildung in
Systemischer Beratung, Supervision und Stressprävention. Seit 2019 arbeitet er
als Familienberater für den Kinderschutzbund Krefeld und leitet dort eine
Väter-Gruppe. Auf seiner Plattform [vaterwelten.de](https://vaterwelten.de)
bietet er deutschlandweit Gesprächskreise, Kurse und Workshops für Väter und
Unternehmen an.  
  
Heiner Fischer engagiert sich ehrenamtlich im [Bundesforum
Männer,](https://bundesforum-maenner.de) der[ ](http://lag-
vaeterarbeit.nrw)[LAG Väterarbeit NRW](http://lag-vaeterarbeit.nrw) und leitet
die Kampagne [#Vaterschaftistmehr](https://vaterschaftistmehr.de), die
jährlich am Vatertag stattfindet.

##  Alle Video-Seminare auch in der App von ElternLeben.de

**Hole dir nach dem Kauf die ElternLeben.de-App** für Offline-Zugriff auf alle
Lektionen, Erinnerungen für  
kostenfreie Live-Events und exklusive Rabatte auf neue eBooks und Video-
Seminare.

[ 
](https://play.google.com/store/apps/details?id=com.elternleben.app)

[ 
](https://apps.apple.com/app/id1611753266)

Dieses Video-Seminar wurde gefördert durch:



