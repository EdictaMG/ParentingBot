---
author: ''
category:
- shop
crawled_at: '2025-03-05T20:22:38.709976'
description: ''
filename: teenager.md
filepath: elternleben/shop/teenager.md
title: Teenager
url: https://www.elternleben.de/shop/teenager/
---

#  Der Shop von ElternLeben.de

Hast du schon Video-Kurse auf ElternLeben.de gekauft? Hier kannst du auf dein
Konto zugreifen.

[Einloggen](https://shop.elternleben.de/s/elternleben/sign_in)

