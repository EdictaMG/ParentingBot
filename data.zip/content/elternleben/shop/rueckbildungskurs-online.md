---
author: ''
category:
- shop
content_type: Product
crawled_at: '2025-03-05T19:44:29.193379'
description: 'Der Online Rückbildungskurs mit Hebamme Karin: ✅ Flexibles Online Training
  ✅ kein teures Abo-Modell ✅ günstig weil gemeinnützig.'
filename: rueckbildungskurs-online.md
filepath: elternleben/shop/rueckbildungskurs-online.md
title: 'Online Rückbildungkurs: Günstiger & flexibler Online Kurs'
url: https://www.elternleben.de/shop/rueckbildungskurs-online/
---

  1. [ Home ](/)
  2. [ Shop ](/shop)
  3. Online-Rückbildungskurs

![Hebamme Karin im
Rückbildungskurs](/fileadmin/_processed_/d/7/csm_Ru__ckbildungskurs_Header_0544de74a9.jpg)

#  Online Rückbildungskurs

Wieder fit mit Hebamme Karin!

[ kostenfrei testen!
](https://shop.elternleben.de/s/elternleben/rueckbildungskurs-
online/preview?lesson_id=144944)

Video-Seminar schon gekauft? | [Hier einloggen](https://elopage.com/s/elternleben/sign_in)  
---|---  
  
Während der Schwangerschaft haben Beckenboden und Bänder ziemlich viel
"ausgehalten", denn die Geburt ist für den Beckenboden ein echter Härtetest.  
**Ein Rückbildungskurs hilft dir wieder fit zu werden.**

![Rückbildungskurs
Responsive](/fileadmin/_processed_/1/a/csm_Ru__ckbildungskurs_Responsive_1080_01_ea3a657a60.png)

Du hast aber gerade **wenig Zeit, um einen Kurs regelmäßig und zu festgelegten
Zeiten Vorort durchzuführen** – du wünschst dir eine erfahrene Hebamme, die
dich mit stärkenden Übungen begleitet?

**Dann ist unser Online Rückbildungskurs perfekt für dich.**  
Du kannst die Übungen von zuhause aus, nach deinem persönlichen Zeit-Rhythmus,
durchführen.**Keine festen Termine, keine Fahrtzeit!**  
Hebamme Karin begleitet dich in den Video-Lektionen. Hast du **Fragen an
Karin? Stelle sie gern** und Karin antwortet dir schnellstmöglich.

**Gestalte deine Rückbildung wie du möchtest:**



**zuhause**



**flexibel**



**mit Baby**

##  Dein Online-Rückbildungskurs mit Hebamme Karin

[ ![](/fileadmin/_processed_/1/7/csm_Online-
Rueckbildungsgymnastik_von_ElternLeben.de_cded8cd9c1.png)
](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))

  * **10 Einheiten à 45 Minuten -** abwechslungsreiches **Videomaterial** mit Quizfragen
  * Lass dir von unserer **professionellen Vertragshebamme Karin** zeigen, dass Rückbildung Spaß bringt und gleichzeitig dein Körpergefühl wieder stärkt
  * **Entscheide selbst** , wann du dir die Zeit nehmen möchtest
  * Kläre mit Karin **deine persönlichen Fragen**. Vielleicht hast du körperliche Einschränkungen oder dir sind Übungen nicht ganz klar, brächtest Alternativen oder einen Erfahrungsaustausch, dann tritt über die Kommentarfunktion mit Karin in Kontakt

**Wichtige Information:**  
Um den Kurs abwechslungsreich zu gestalten, verwenden wir in nur wenigen
Kurseinheiten **Gymnastikhilfen**. Welche Hilfen du genau benötigst, erfährst
du [>>HIER in der Kurs-
Preview](https://elopage.com/s/elternleben/rueckbildungskurs-
online/preview?lesson_id=144944 "Opens external link in new window").

## Online-Rückbildungskurs mit Hebamme Karin  
  
---  
68,00 €  
Einmalige Zahlung – unbegrenzter
Zugang  
Teste die erste Kurseinheit
kostenfrei!  
Vollwertiger Hebammenkurs mit
Zertifikat für die Krankenkasse  
Für Computer, Tablet und
Smartphone  
[jetzt kaufen](https://shop.elternleben.de/s/elternleben/rueckbildungskurs-
online/payment/?displayed_plans_id=33966&plan_id=33966) [kostenfrei
testen](https://elopage.com/s/elternleben/rueckbildungskurs-
online/preview?lesson_id=144944/?displayed_plans_id=33966&plan_id=33966 "Opens
external link in new window")  
[**Hier findest du heraus, wie der Rückbildungskurs von
deiner**Krankenkasse** übernommen wird!**](/shop/rueckbildungskurs-
online/#Krankenkasse)  
  
**Du trainierst zeitlich flexibel, bequem von zuhause und kannst alle
Lektionen so oft du willst wiederholen.**  
  
Damit wir alle Eltern mit unseren Produkten unterstützen können, bieten wir
Ermäßigungen. Falls du dir die Teilnahme nicht leisten kannst, schreibe uns
eine E-Mail an
[info[at]elternleben.de](javascript:linkTo_UnCryptMailto\(%27nbjmup%2BjogpAfmufsomfcfo%5C%2Fef%27\);)

**ElternLeben.de ist gemeinnützig.** Um eine werbefreie und weitestgehend
kostenlose Plattform zu betreiben, bei der User nicht mit ihren Daten
bezahlen, sammeln wir **Spenden** und verkaufen unsere **Produkte** so
preiswert wie möglich. Alle Einnahmen werden für ElternLeben.de verwendet.
Danke für deine Unterstützung!

##  Was Eltern über den Online-Rückbildungskurs sagen

**Sterne aus Bewertungen**

**Weiterempfehlungen**

![Icon graue
Anfuehrungsstriche](/fileadmin/Assets/Icons/anfuehrungsstriche_grau.svg)

![Icon graue
Anfuehrungsstriche](/fileadmin/Assets/Icons/anfuehrungsstriche_grau.svg)

[Alle Bewertungen anschauen](https://de.surveymonkey.com/stories/SM-H5TVQ7P2/)

##  Darum ist ein Rückbildungskurs so wichtig

Während der Schwangerschaft haben Beckenboden und Bänder ziemlich viel
"ausgehalten". **Die Geburt ist für den Beckenboden ein echter Härtetest**.
Auch wenn du momentan vielleicht keine Beschwerden hast –
**Beckenbodentraining** (Stärkung der Beckenbodenmuskulatur) **schützt dich
vor Folgeschäden**. Denn Probleme, die durch einen geschwächten Beckenboden
auftreten, zum Beispiel **Gebärmuttersenkungen** oder **Inkontinenz** , können
sich manchmal erst lange Zeit nach der Geburt, während der Wechseljahre
zeigen.

Unser Online-Rückbildungskurs ist genau darauf ausgerichtet:  
Den Beckenboden nachhaltig zu stärken, die Rücken- und Bauchmuskulatur zu
trainieren und körperlich insgesamt wieder ins Gleichgewicht zu kommen.  
**Dieser Kurs stärkt dein Körpergefühl und macht dich fit für die Zeit nach
der Geburt – freue dich drauf!**

##  Wirf einen Blick in das Video-Seminar!

Um einen optimalen Eindruck von dem Video-Seminar zu erhalten,  
schaue dir nachfolgend eine Vorschau an!

Inhalt  
---  
[**Herzlich Willkommen**](https://elopage.com/s/elternleben/rueckbildungskurs-online/preview?lesson_id=144944 "Opens external link in new window") | [Preview anzeigen](https://elopage.com/s/elternleben/rueckbildungskurs-online/preview?lesson_id=144944 "Opens external link in new window")  
[**🎬 1. Für einen starken Beckenboden**  
Übungen im Liegen, Sitzen, Stehen](https://elopage.com/s/elternleben/rueckbildungskurs-online/preview?lesson_id=144952 "Opens external link in new window") | [kostenfrei testen!](https://elopage.com/s/elternleben/rueckbildungskurs-online/preview?lesson_id=144952 "Opens external link in new window")  
**🎬 2. Beckenboden-Training im Alltag**  
Übungen mit dem Hocker  
**🎬 3. Bauchmuskeln und Rektusdiastase**  
Bauchmuskeltraining und Ertasten der Rektusdiastase  
**🎬 4. Stärkendes Muskeltraining**  
Übungen mit dem Ball  
**🎬 5. Für einen starken Rücken**  
Übungen für den Rücken und rückengerechte Haltungen  
**🎬 6. Stärkendes Muskeltraining**  
Übungen mit dem Gymnastikball  
**🎬 7. Gleichgewicht und Koordination**  
Übungen im Liegen, Sitzen, Stehen  
**🎬 8. Stärkendes Muskeltraining**  
Übungen mit dem Gymnastikband  
**🎬 9. Bewegung für Mutter und Kind**  
Übungen zusammen mit deinem Baby  
**🎬 10. Basisübungen und schwierigere Variationen**  
Übungen im Liegen, Sitzen, Stehen  
  
##  Unsere erfahrene Hebamme Karin Hackbarth



Karin Hackbarth

Online-Beratung

Karin Hackbarth berät euch als **Hebamme** in unserer [Online-
Beratung](https://www.elternleben.de/ueber-stell-uns-deine-frage/).

Sie ist seit 1996 Hebamme und hat 15 Jahre lang neben ihrer Freiberuflichkeit
auch in einer Klinik gearbeitet. Karin Hackbarths Schwerpunkte sind
Schwangerenberatung, Geburtsvorbereitung, Rückbildungsgymnastik sowie
Wochenbettbetreuung.  
  
Ihr ist wichtig, dass Frauen und Familien eine vertrauensvolle und
fachkompetente Begleitung durch die Schwangerschaft und das erste Lebensjahr
erfahren. In Zeiten der Informationsüberflutung und damit großer
Verunsicherung ist es Karin wichtig, die Frauen zu stärken und zu
selbstbewußten Entscheidungen zu motivieren. Karin Hackbarth stellt ihr
langjähriges Fachwissen in unserem [
](https://www.elternleben.de/shop/rueckbildungskurs-online/ "Opens external
link in new window")**[>>Online-
Rückbildungskurs](https://www.elternleben.de/shop/rueckbildungskurs-online/
"Opens external link in new window")** zur Verfügung.

##  FAQs zum Rückbildungskurs

1\. Wird der Online-Rückbildungskurs von der Krankenkasse erstattet?

**Einige Kassen erstatten bereits digitale Rückbildungsangebote**. Wir können
dir nicht versichern, ob dies auch bei deiner Krankenkasse der Fall ist.
Grundsätzlich erfüllt unser digitale Rückbildungskurs die Kriterien für die
Erstattung durch die Krankenkasse. Um mit deiner Krankenkasse vorab zu klären,
ob die Kosten übernommen werden, haben wir für dich ein ausführliches Dokument
erstellt, welches du deiner Kasse vorlegen kannst. [Das Dokument findest du
hier.](https://www.elternleben.de/fileadmin/Startseite/5_Shop/Video-
Seminare/a_Dokumente/Rueckbildungskurs-Einreichung-bei-der-
Krankenkasse_2024.pdf)  
Nach Absolvieren des Online-Kurses erhältst du ein Zertifikat, welches deine
Krankenkasse für die Kostenerstattung benötigt.

![Logo DAK
Krankenkasse](https://www.elternleben.de/fileadmin/Startseite/5_Shop/Video-
Seminare/DAK_Ges_Logo_4c_Claim.jpg)

Die DAK übernimmt im Rahmen der DAK MamaPLUS Leistungen bis zu 50 Euro für
Online-Geburtsvorbereitungskurse und -Rückbildungsgymnastikkurse für Frauen,
die vorhandenes Wissen festigen wollen. Hierunter fallen zum Beispiel
Zweitmamas.  
Hier findest du die Voraussetzungen für DAK MamaPLUS:
[www.dak.de/mamaplus](https://www.dak.de/mamaplus)

**Techniker Krankenkasse (TK)** : Mithilfe des Bonus Programms der Techniker
Krankenkasse habt ihr die Möglichkeit eure gesammelten Punkte durch eine
gesundheitsfördernde Maßnahme, wie zum Beispiel unseren Online-
Rückbildungskurs, einzulösen.

2\. In welchem zeitlichen Abstand soll man die Kurseinheiten machen und wie
oft soll ich diese wiederholen?

Da Rückbildungskurse üblicherweise einmal in der Woche stattfinden, könnt ihr
ca. **alle 5- 7 Tage zur nächsten Folge gehen**. Da ihr den Vorteil habt, die
Folgen wieder aufrufen zu können, könnt ihr die **gleichen Einheiten gerne
zweimal (auch in einer Woche)** durchführen bevor ihr im Kurs
weitergeht.Wichtig ist, dass ihr bei der vorgegebenen Reihenfolge bleibt. Die
einzelnen Kursstunden könnt ihr dann 1-3-mal machen, so wie es sich gut für
euch anfühlt. Nach dem ersten kompletten Durchlauf, sucht euch gern die
Stunden heraus, die für euch am besten sind und wiederholt sie, so oft ihr
mögt.

3\. Wie lange kann man die Übungseinheiten nach Abschluss des Kurses noch
"nachtrainieren"?

**Ihr habt dauerhaften Zugang zu diesem Rückbildungskurs.** Gern könnt ihr die
Übungen solange weiter durchführen, wie ihr möchtet. Da viele Muskelgruppen
und der Beckenboden angesprochen werden, ist es nicht einseitig. Wenn ihr für
euch mmer mehr Wiederholungen einplant, könnt ihr euer Training auch noch
erhöhen.

4\. Ab wann nach der Geburt sollte man mit einem Rückbildungskurs beginnen?

Nach einer natürlichen Geburt ohne größere Geburtsverletzungen könnt ihr
**nach etwas 6 bis 8 Wochen mit den Rückbildungsübungen beginnen.** Mit
Rückbildungsgymnastik wird bei natürlicher Geburt etwa 6 bis 8 Wochen nach der
Entbindung begonnen. Ist der Damm gerissen oder wurde ein Dammschnitt
durchgeführt, so solltet ihr erst mit der Rückbildung beginnen, wenn die Naht
bzw. Wunde verheilt ist. Bei einem Kaiserschnitt solltet ihr nach ca. 8 bis 10
Wochen mit der Rückbildung beginnen, also etwas später. Generell gilt: Wartet
die Nachsorgeuntersuchung bei deiner Gynäkologin/deinem Gynäkologen ab, bevor
du mit der Rückbildung anfängst. Diese findet ca. 6 Wochen nach der Geburt
statt.

5\. Wie lange nach der Geburt macht ein Rückbildungskurs noch Sinn?

Es gibt hier kein „zu spät“! Es ist ratsam, die Rückbildung **rechtzeitig nach
der Geburt** zu beginnen (siehe Punkt 3.). Aber wenn das nicht möglich war,
bringt es auch zu einem späteren Zeitpunkt immer noch etwas, den Beckenboden
zu trainieren.

6\. Wie kann ich sicher gehen, dass ich auch tatsächlich den Beckenboden
anspannen Ich bin mir nicht sicher, ob ich ihn überhaupt spüre.

Gerade beim ersten Kind ist es schwierig zu erkennen, ob die richtigen Muskeln
angespannt werden. Es ist eine recht kleine Muskelanspannung und wenig
spürbar.  
  
Wenn ihr euch mit euren Sitzbeinhöckern (die Knochen am Becken, die schmerzen
können, wenn man lange auf einer harten Unterfläche sitzt oder lange Fahrrad
fährt) auf eure Handflächen setzt und dann euren Beckenboden anspannst, dann
fühlt es sich so an, als ob die Knochen sich aufeinander zubewegen. Dies
passiert durch die Aktivierung der Beckenbodenmuskulatur.  
  
Um den Beckenboden aber erstmal zu finden, hilf die Vorstellung das ihr eine
volle Blase habt und dringend ein WC benötigt. Die Anspannung die ihr dann
automatisch durchführt, da eure Blase sich noch nicht leeren darf, ist die
Anspannung der Beckenbodenmuskulatur.

7\. Ich habe eine Rektusdiastase. Helfen die Übungen dabei, diese zu
schließen, oder gibt es noch etwas, was ich tun kann, damit sich diese besser
schließen kann?

**Die Übungen im Video helfen auf jeden Fall eure Rectusdiastase zu
verbessern!**  
  
Achtet im Alltag gut darauf, euch immer über die Seite hinzulegen und
aufzustehen. Solltet ihr häufiger mal im Vier Füssler-Stand sein (zum Beispiel
beim Spielen mit den Kindern), dann achtet bewusst darauf, das die
Bauchmuskeln angespannt werden. Ein immer wieder auftretender erhöhter Druck
im Bauchraum sollte auch vermieden werden, z.B. durch viel Luft im Bauch oder
Verstopfungen.  
  
Wenn eure Rectusdiastase 3 Querfinger breit ist oder sogar grösser, dann würde
ich eine Kontrolle beim Hausarzt/Hausärztin empfehlen. Eine Verordnung für
Physiotherapie kann dann sehr sinnvoll sein.  
  
Neben dem regelmäßigen Training der schrägen Bauchmuskeln ist es oft auch
einfach die Zeit, die bewirkt das sich eine Rectusdiastase von allein wieder
schließt.

8\. Kann ich im digitalen Rückbildungskurs Fragen stellen?

**Ja!** Unter jeder Kurseinheit gibt es die Möglichkeit, Fragen in Form eines
Kommentars zu stellen. Diese werden dann direkt von Hebamme Karin als Antwort
auf den Kommentar im Kurs beantwortet.

9\. Kann ich den Kurs auch mit Baby durchführen?

**Explizit bezieht nur eine Einheit des Kurses das Baby aktiv mit in die
Übungen ein.** Allerdings kannst du dein Baby natürlich **immer zu dir legen,
wenn du die Übungen machst**. Beim digitalen Kurs hast du den zusätzlichen
Vorteil, dass du jederzeit unterbrechen kannst, wenn dein Kleines mehr
Aufmerksamkeit braucht. Viele Babys finden es lustig, Mama beim „Turnen“ zu
beobachten. Achte bitte darauf, dass dein Baby in einem sicheren Abstand
liegt, sodass es dich zwar noch gut sehen kann, du es aber bei den Übungen
nicht aus Versehen stoßen kannst.

##  Du hast noch Fragen zum Video-Seminar?

Schreibe uns eine E-Mail an
[info[at]elternleben.de](javascript:linkTo_UnCryptMailto\(%27nbjmup%2BjogpAfmufsomfcfo%5C%2Fef%27\);)

### Das könnte dich auch interessieren

[ ![Handbuch Ernährung -
Cover](/fileadmin/_processed_/2/2/csm_Handbuch_Ernaehrung_teaser_909bd25597.png)
Handbuch Ernährung für Babys im 1. Lebensjahr ](/shop/ernaehrung-fuer-babys/)

[ ![Handbuch 4 Grundbedürfnisse -
Cover](/fileadmin/_processed_/6/6/csm_Handbuch_Grundbeduerfnisse_teaser_eb914d5136.png)
Mini-Handbuch Babys im ersten Lebensjahr – Die vier Grundbedürfnisse: Schlaf,
Nähe, Schreien, Nahrung ](/shop/babys-im-ersten-lebensjahr/)

[ ![Video-Seminar Selbstfürsorge –
Responsive](/fileadmin/_processed_/2/b/csm_VideoSeminar_Selbstfuersorge_teaserbild_v2_e3ba0508ca.png)
Video-Seminar Selbstfürsorge für gestresste Eltern ](/shop/video-seminar-
selbstfuersorge-fuer-gestresste-eltern/)

