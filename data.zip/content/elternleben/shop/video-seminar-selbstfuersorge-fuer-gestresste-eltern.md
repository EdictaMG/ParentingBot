---
author: ''
category:
- shop
crawled_at: '2025-03-05T19:48:25.747412'
description: Wie Mütter und Väter Ursachen von Stress erkennen, ihn wahrnehmen und
  mit Stress umgehen können, lernst du in diesem Selbstfürsorge-Seminar mit Nadine
  Büttner.
filename: video-seminar-selbstfuersorge-fuer-gestresste-eltern.md
filepath: elternleben/shop/video-seminar-selbstfuersorge-fuer-gestresste-eltern.md
title: Video-Seminar Selbstfürsorge für gestresste Eltern
url: https://www.elternleben.de/shop/video-seminar-selbstfuersorge-fuer-gestresste-eltern/
---

  1. [ Home ](/)
  2. [ Shop ](/shop)
  3. Selbstfürsorge für gestresste Eltern

![Versteckende Frau unter ihrer Decke](/fileadmin/Startseite/5_Shop/Video-
Seminare/Keyvisual_Video-Seminar_Selbstfu__rsorge_taisiia-stupak-sePA_raTCUk-
unsplash_cut.jpg)

#  Selbstfürsorge für gestresste Eltern

Das Video-Seminar für mehr Gelassenheit im Familienalltag

[ Jetzt teilnehmen! ](https://shop.elternleben.de/s/elternleben/video-seminar-
selbstfuersorge-fuer-gestresste-eltern/payment)

##  Dein Video-Seminar mit Dr. Nadine Büttner

[ ![](/fileadmin/_processed_/a/1/csm_Video-
Seminar_Selbstfu__rsorge_fuer_gestresste_Eltern_8c03208c93.png)
](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))

  * Ursache und Bedeutung von Stress.
  * Was positiver und negativer Stress ist.
  * Wie du mit Achtsamkeit Stress vorbeugen kannst.
  * Wie du Wahrnehmungsübungen durchführen kannst.
  * Wie ein Bad in Selbstliebe funktioniert.
  * Wie du Achtsamkeit mit deinen Kindern üben kannst.
  * Wie du ins Tun kommst.

**_„Äußere Stressquellen lassen sich nur bedingt beeinflussen. Wichtig ist es,
unsere inneren Stressquellen zu erkennen und zu bewältigen."_**

Nadine Büttner

## Du erhältst  
  
---  
 unbegrenzten Zugriff  
 10 kompakte Videos mit Nadine:
insgesamt ca. 2 Std.  
 fundiertes Wissen und
praktische Anregungen für deinen Alltag  
 Workbook**** zum Ausdrucken  
 Übungen zur Selbstreflexion und
Selbsteinfühlung  
 Platz für deine Fragen, die von
Nadine Büttner beantwortet werden  
 Podcast-Version (Audio only)  
34,90 €  
[ Jetzt kaufen ](https://shop.elternleben.de/s/elternleben/video-seminar-
selbstfuersorge-fuer-gestresste-eltern/payment)  
  
**Vielleicht wünschst du dir mehr Verständnis für dich selbst und Gelassenheit
gegenüber stressigen Situationen?**  
Du möchtest wissen, was deine Ursachen für Stress sind, was du in akuten
Stressmomenten tun kannst? Dir ist wichtig zu lernen, welche blockierenden
Verhaltensmuster du hast?

Dann ist unser Video-Seminar mit Nadine bestimmt eine Unterstützung für dich!

##  Blick ins Video-Seminar

Inhalt  
---  
[ Willkommen! ](https://elopage.com/s/elternleben/video-seminar-selbstfuersorge-fuer-gestresste-eltern/preview?lesson_id=1079092&pk_vid=df9b14d1e00e6f6c1695215354691c0a "Willkommen!") |  [ Preview anzeigen ](https://elopage.com/s/elternleben/video-seminar-selbstfuersorge-fuer-gestresste-eltern/preview?lesson_id=1079092&pk_vid=df9b14d1e00e6f6c1695215354691c0a "Preview anzeigen: Willkommen!")  
[ 🎬 Das erwartet dich ](https://elopage.com/s/elternleben/video-seminar-selbstfuersorge-fuer-gestresste-eltern/preview?lesson_id=1079093&pk_vid=df9b14d1e00e6f6c1695215395691c0a "Das erwartet dich") |  [ Preview anzeigen ](https://elopage.com/s/elternleben/video-seminar-selbstfuersorge-fuer-gestresste-eltern/preview?lesson_id=1079093&pk_vid=df9b14d1e00e6f6c1695215395691c0a "Preview anzeigen: Das erwartet dich")  
🎬 1\. Ursache und Bedeutung von Stress  
🎬 2\. Positiver Stress  
🎬 3\. Mit akutem Stress umgehen  
🎬 4\. Inneres Gleichgewicht schaffen  
🎬 5\. Achtsamkeit auf vier Ebenen  
🎬 6\. Achtsam mit Kindern  
🎬 7\. Ins Tun kommen  
🎬 Alle Übungen  
🔊 Als Podcast (Audio only)  
  
[ Jetzt kaufen ](https://shop.elternleben.de/s/elternleben/video-seminar-
selbstfuersorge-fuer-gestresste-eltern/payment)

##  Nadine Büttner teilt ihr Wissen und ihre Erfahrung



Nadine Büttner

Online-Beratung & Autorin

Nadine Büttner ist auf ElternLeben.de Expertin rund um das Thema konkreter
**Erziehungsfragen im Alltag**. Für ElternLeben.de schreibt sie Inhalte für
den Bereich Elternwissen. Auch aus ihrer Feder geflossen ist das [
](https://www.elternleben.de/shop/handbuch-alltag-mit-kleinkind/ "Opens
external link in new window")**[>>Handbuch Spielen, Lernen, Wachsen – Dein
Alltag mit Kleinkind](https://www.elternleben.de/shop/handbuch-alltag-mit-
kleinkind/ "Opens external link in new window")**.

Sie ist erfahrene Diplom Sozialpädagogin, Montessori Pädagogin, Safe® Mentorin
& NLP Practitioner. Mit mehrjähriger Führungserfahrung im Bereich der
ambulanten Kinder- und Jugendhilfe, engagiert sie sich freiberuflich für
Eltern und pädagogische Fachkräfte. Zudem begleitet die dreifach Mama
Führungspersonen im Bereich der Gesprächsführung und Selbstfürsorge.

Nadine Büttner hat bewusst eine lange Elternzeit mit ihren drei Kindern
genossen. Sie liebt das Reisen mit Kindern und setzt sich stark dafür ein,
dass sie schon von Anfang an als individuelle Persönlichkeiten wahrgenommen
werden.

Nadine "live":**[hier stellt sich Nadine persönlich im Video
vor](https://www.elternleben.de/ueber-uns/experten/nadine-buettner/)!**

##  Du hast noch Fragen zum Video-Seminar?

Schreibe uns eine E-Mail an
[info[at]elternleben.de](javascript:linkTo_UnCryptMailto\(%27nbjmup%2BjogpAfmufsomfcfo%5C%2Fef%27\);)

### Das könnte dich auch interessieren

[ ![Video-Seminar Wutausbrüche begleiten –
Responsive](/fileadmin/_processed_/5/0/csm_VideoSeminar_Wutausbrueche_teaserbild_01_1a710cf8cb.png)
Video-Seminar Wutausbrüche begleiten ](/shop/video-seminar-wutausbrueche-
begleiten/)

[ ![Video-Seminar Mit Kind gesund durchs Jahr –
Responsive](/fileadmin/_processed_/6/5/csm_VideoSeminar_Gesundheit_teaser_01_b79a597edb.png)
Video-Seminar Mit Kind gesund durchs Jahr ](/shop/video-seminar-mit-kind-
gesund-durchs-jahr/)

[ 
Handbuch Mediennuntzung von Kindern und Jugendlichen ](/shop/mediennutzung/)

Dieses Video-Seminar wurde gefördert durch:



