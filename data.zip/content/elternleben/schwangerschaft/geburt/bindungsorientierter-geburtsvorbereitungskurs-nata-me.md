---
author: ''
category:
- schwangerschaft
- geburt
crawled_at: '2025-03-05T19:55:53.733646'
description: Online-Geburtsvorbereitungskurs NATA ME konzentriert sich auf die Vertiefung
  der Bindung zwischen Baby und Mutter. Unter der Geburt in Verbindung bleiben.
filename: bindungsorientierter-geburtsvorbereitungskurs-nata-me.md
filepath: elternleben/schwangerschaft/geburt/bindungsorientierter-geburtsvorbereitungskurs-nata-me.md
title: Geburtsvorbereitung mit NATA ME - bindungsorientierter Geburtsvorbereitungskurs
url: https://www.elternleben.de/schwangerschaft/geburt/bindungsorientierter-geburtsvorbereitungskurs-nata-me/
---

#  Geburtsvorbereitung mit NATA ME - bindungsorientierter
Geburtsvorbereitungskurs

  * Unser**Online-Geburtsvorbereitungskurs** konzentriert sich auf die **Vertiefung** der **Bindung** zwischen Baby und Mutter. Dies ist eine **große Bereicherung** zum regulären Geburtsvorbereitungskurs. Mutter und Baby können sich mithilfe der Kraft **vorgeburtlicher Kommunikation** , durch Yin- und Faszien Yoga, durch gezielte Pranayama Yoga Atmung und Meditation **gemeinsam auf die Geburt vorbereiten** und damit auch unter der Geburt in Verbindung bleiben. **[>>Buche hier deinen Online-Geburtsvorbereitungskurs - Bindung mit NATA ME](https://www.elternleben.de/shop/online-geburtsvorbereitungskurs/)**

Inhalt

1. Geburtsvorbereitung - Bindung mit NATA ME

2. Der Geburtsvorbereitungskurs - NATA ME ist wie für dich gemacht wenn:

3. 6 Folgen NATA ME Geburtsvorbereitung

4. Wer ist die Kursleiterin?

Lesezeit: Etwa **2 Minuten**

![Hebamme sitzt frontal und hält Hände an die
Brust](/fileadmin/_processed_/b/6/csm_Geburtsvorbereitungskurs_Bindung_bindungsorientiert_Inken_Harring-
Andresen_9cb7d9edbf.jpg)

##  Geburtsvorbereitung - Bindung mit NATA ME

**NATA ME** ist ein **neues Konzept** für Geburtsvorbereitung, um die
**vorgeburtliche Bindung** zwischen Baby und Mutter zu stärken. Durch
**vielfältige** , wunderbare **Entspannungsübungen** , werden Körper, Geist
und Seele tiefer verbunden und **kräftigen Mutter** und **Baby** für die
**Geburt.** Freue dich auf 6 Folgen zwischen 9 und 30 Minuten, insgesamt ca.
105 Minuten Online-Videos:

  * Dauerhaft online verfügbar
  * NATA ME: Idee, Konzept, Vision
  * Atem- und Entspannungsübungen
  * Yin Yoga für die innere Ruhe
  * Meditation mit dem Baby
  * Übungen und Vorbereitung auch mit Partner

##  Der Geburtsvorbereitungskurs - NATA ME ist wie für dich gemacht wenn:

  * du zeitlich flexibel sein willst
  * du bequem von zuhause aus Übungen machen möchtest
  * du die Übungen bis zur Geburt beliebig oft wiederholen möchtest
  * du dich auch nur auf einen Bereich z.B. Yin Yoga konzentrieren möchtest
  * du mal 'zwischendurch' eine kleine Auszeit durch Meditation brauchst
  * du dich auf den Dreiklang von Körper, Geist und Seele einlassen möchtest

##  6 Folgen NATA ME Geburtsvorbereitung

Diese Inhalte erwarten dich:

  1. Folge: NATA ME - Idee, Konzept und Vision
  2. Folge: Verbindung zu deinen Atemräumen
  3. Folge: Yin Yoga
  4. Folge: Meditation mit dem Baby
  5. Folge: Atmung, Yin Yoga, Meditation für die Geburt
  6. Folge: Atmung, Yin Yoga, Meditation für werdende Eltern

##  Wer ist die Kursleiterin?

Inken Harring-Andresen ist seit 1998 freiberufliche Hebamme und
Familienhebamme. Die Mutter von zwei Töchtern ist seit 2004 in der
Elternberatung und als Kursleiterin tätig. Seit 2008 ist sie DELFI©
Multiplikatorin. 2015 gründete Inken ihre Hebammenpraxis Seelenzeit.  
  
Den Schwerpunkt ihrer Arbeit widmet sie der bindungsorientierten
Geburtsvorbereitung und Geburt. Sie hat dazu ein eigenes Konzept NATA ME ©
entwickelt und bietet es in Verbindung mit Yoga als Kurs oder als
Einzelbegleitung an. Die vorgeburtliche Kommunikation und Bindung zum Baby
lässt für eine Familie das Gefühl von Vertrauen und Sicherheit entstehen,
welches für das weitere Leben eine wichtige Grundlage bildet.

