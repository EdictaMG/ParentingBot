---
author: ''
category:
- teenager
- freundschaft-und-liebe
crawled_at: '2025-03-05T19:44:34.787374'
description: 'Kinder werden Jugendliche: Wenn Eltern mit Themen wie Liebe, Verhütung,
  Erstes Mal und Co. konfrontiert werden. Tipps zur Orientierung für Familien'
filename: erste-liebe-erstes-mal.md
filepath: elternleben/teenager/freundschaft-und-liebe/erste-liebe-erstes-mal.md
title: Verhütung, erstes Mal & Co. - Jugendliche und die erste Liebe
url: https://www.elternleben.de/teenager/freundschaft-und-liebe/erste-liebe-erstes-mal/
---

#  Verhütung, erstes Mal & Co. - Jugendliche und die erste Liebe

Wenn aus Kindern Jugendliche werden, steht ihre Welt Kopf. Und auch als Eltern
fühlt man sich manchmal ganz schön verunsichert: Wie kann ich meine
Tochter/meinen Sohn durch diese turbulente Zeit begleiten? Welche
Informationen sollte ich vermitteln und wie finde ich eine gute Balance
zwischen Begleitung und Einmischen?

Inhalt

1. Tipps zur Orientierung für Eltern zum Thema Verhütung, erstes Mal und Co. als Download

2. Mädchen – weibliche Bezugsperon ist hilfreich

3. Jungs – männliche Bezugsperson ist hilfreich

4. Gib zu, wenn du aufgeregt bist

5. Sicherheit von Verhütungsmitteln

6. Coitus Interruptus – keine sichere Verhütungsmethode

7. Wann ist der 'richtige' Zeitpunkt für 'das erste Mal'?

8. Viele Schritte bis zum Sex

9. Pornos – hilfreich oder nicht?

10. Liebe und Verliebtheit – Unterschiede

11. Tipp zum Schluss – Intimes Frage-Buch

Lesezeit: Etwa **5 Minuten**

![Verhütung: Kondome, Anti-Baby-Pille und
Co.](/fileadmin/_processed_/1/6/csm_Tipps_Verhu__tung_Erstes_Mal_u_Co_Tipps_f_Teenie_Eltern_0e49ffbebe.jpg)

##  Tipps zur Orientierung für Eltern zum Thema Verhütung, erstes Mal und Co.
als Download

Klicke[ **> > Hier <<
**](https://www.elternleben.de/fileadmin/Startseite/1_Elternwissen/a_Downloads/Download-
Tipps_zur_Orientierung_Verhu__tung__erstes_Mal_und_Co..pdf)um die Tipps zur
Orientierung für Mütter und Väter als PDF herunterzuladen.

##  Mädchen – weibliche Bezugsperon ist hilfreich

Für Mädchen ist ein Gespräch mit der Mutter oder einer anderen weiblichen
Bezugsperson wichtig – über körperliche Veränderungen wie die erste
Menstruation, BH-Auswahl, Haarwachstum aber auch über die erste Liebe, Sex und
Verhütung. Als Vater kannst du deiner Tochter anbieten, sich an dich zu
wenden, wenn sie etwas über die männliche Perspektive erfahren möchte.

##  Jungs – männliche Bezugsperson ist hilfreich

Für Jungen ist es toll, wenn sie eine männliche Bezugsperson haben, die ein
ruhiges Gespräch über körperliche Veränderungen und erste Liebe mit ihnen
führt und sich als Ansprechpartner bei weiteren Fragen zur Verfügung stellt.
Doch du darfst und solltest auch als Mutter deinem Sohn anbieten, ihm Fragen
zu beantworten oder zuzuhören, wenn er etwas loswerden will. Wenn er Interesse
hat, kannst du ihm auch erzählen, wie du als Mädchen die Pubertät erlebt hast
und, was du dir von Jungen gewünscht hast und welche Eigenschaften dir an
Jungen gefallen haben.

##  Gib zu, wenn du aufgeregt bist

Versuch', so locker und unbefangen wie möglich über das Thema zu sprechen.
Wenn du aufgeregt bist, kann es auch passen, wenn du ehrlich zugibst: „Über so
etwas spricht man ja nicht alle Tage, deshalb ist es auch für mich etwas
seltsam. Aber lass' es uns doch einfach mal probieren ...“

##  Sicherheit von Verhütungsmitteln

Anfangs kannst du erfragen, was dein Sohn/deine Tochter bereits über Verhütung
und das erste Mal weiß. Sorge dafür, dass er/sie die wichtigsten
Verhütungsmittel und deren Sicherheit kennt. Kondome schützen vor
Geschlechtskrankheiten, bieten aber nur mäßigen Schutz vor einer
Schwangerschaft: 2-12 von 100 Frauen, die mit Kondomen verhüten, werden pro
Jahr trotzdem schwanger. Die Pille ist deutlich sicherer, hat dafür aber oft
Nebenwirkungen wie Stimmungsschwankungen, Gewichtszunahme, u.a. und birgt das
Risiko von Thrombosen, die sehr gefährlich werden können. Als besonders
riskant gelten Pillen der dritten und vierten Generation, aber auch bei
anderen Präparaten wird das Risiko erhöht. Deshalb sollten hormonelle
Verhütungsmittel Jugendlichen nur nach gutem Abwägen empfohlen werden. Und
auch hier gilt: Kein Verhütungsmittel ist 100% sicher! Auch müssen
Besonderheiten beachtet werden, zum Beispiel ist die Wirksamkeit der Pille bei
bestimmten Medikamenten wie Antibiotika eingeschränkt und wenn drei bis vier
Stunde nach der Einnahme Durchfall oder Erbrechen auftritt, ist die Sicherheit
nicht mehr gewährleistet.

##  Coitus Interruptus – keine sichere Verhütungsmethode

Vorsichtshalber sollten Eltern erwähnen, dass der sogenannte „Coitus
Interruptus“ (der Junge zieht seinen Penis kurz vor dem Orgasmus aus der
Scheide heraus) extrem unsicher ist: Etwa 27 von 100 Frauen, die so verhüten,
werden pro Jahr schwanger. Auch bei anderen intimen Berührungen wie dem
Petting, ist Vorsicht geboten: Wenn der Junge Samenflüssigkeit an der Hand hat
und damit das Mädchen im Intimbereich streichelt, kann das im Einzelfall eine
Schwangerschaft zur Folge haben. Auch, wenn „nur“ Petting stattfindet, kann
also ein Kondom sinnvoll sein.

##  Wann ist der 'richtige' Zeitpunkt für 'das erste Mal'?

Sprich' mit deiner Tochter/deinem Sohn ebenfalls über die emotionalen Aspekte
von Sexualität. Auch wenn viele Eltern am liebsten hätten, dass ihr Kind bis
zur Ehe oder zumindest bis zur Volljährigkeit auf Sex verzichtet – diese
Entscheidung treffen allein die jungen Menschen! Du darfst und solltest aber
ehrlich erklären, weshalb du dir wünschst, dass dein Kind diesen Schritt nicht
leichtfertig und nicht zu früh geht: Wegen der Gefahr einer Schwangerschaft,
die nie ganz ausgeschlossen werden kann und auch, weil es viel bedeutet, mit
jemandem zu schlafen. Vielleicht auch wegen persönlicher Erfahrungen. Du
kannst darauf hinweisen, dass durch Sex eine besonders enge Bindung zwischen
zwei Menschen entsteht und man sich sehr verletzlich macht. Nicht immer sind
die ersten sexuellen Erfahrungen schön – gewissermaßen muss man Sex auch erst
„lernen“ und deswegen können die ersten Erlebnisse auch unangenehm oder
peinlich sein. Deshalb ist es ratsam, nur mit jemandem zu schlafen, wenn man
ihm/ihr wirklich vollkommen vertraut und einander sehr gut kennt. Im Rückblick
finden die wenigsten Menschen, zu spät mit Sex begonnen zu haben – viele
bedauern aber, dass sie sich nicht mehr Zeit gelassen haben.

##  Viele Schritte bis zum Sex

Auf dem Weg zum Geschlechtsverkehr gibt es viele Zwischenschritte wie den
ersten Kuss, den ersten Zungenkuss, das erste Mal in einem Bett liegen und eng
aneinander gekuschelt einschlafen, Streicheln an verschiedenen Körperstellen,
usw. … Ermutige deine Tochter/deinen Sohn, sich Zeit zu lassen, um diesen
Prozess in Ruhe zu genießen, anstatt ihn zu überstürzen.

##  Pornos – hilfreich oder nicht?

Für Jugendliche ist es beruhigend, wenn die Eltern beiläufig erwähnen, dass es
völlig natürlich und sogar hilfreich ist, seinen eigenen Körper zu entdecken.
Pornos führen allerdings oft zu Sucht und sind Frauen gegenüber entwürdigend –
das kannst du deinem Kind erklären und damit begründen, weshalb du ihm/ihr
empfiehlst, davon die Finger zu lassen.

##  Liebe und Verliebtheit – Unterschiede

Eine hilfreiche Information ist auch, dass es einen Unterschied zwischen
Verliebtheit und Liebe gibt: Die Verliebtheitsphase dauert meist zwischen
sechs und achtzehn Monaten. In dieser Zeit spielen die Hormone verrückt und
man schwebt auf Wolke sieben … das ist wunderschön, birgt aber auch Gefahren:
Wir sehen den anderen mit einer rosaroten Brille, die uns nur seine tollen
Seiten zeigt. Erst später, wenn die vielen Schmetterlinge im Bauch sich
langsam beruhigen, merken wir deutlich, welche Schwächen der Auserwählte hat –
und manchmal bedeutet das auch einen ziemlich harten Aufprall in die Realität.
Manchmal merkt man dann: „Es passt doch nicht zwischen uns!“ Deshalb ist es
riskant, zu früh zu intim zu werden, weil man den anderen dann oft noch nicht
realistisch einschätzen kann – das gilt für Jugendliche ebenso wie für
Erwachsene.

##  Tipp zum Schluss – Intimes Frage-Buch

Biete deinem Kind an, sich jederzeit an dich zu wenden, wenn es Probleme hat
oder etwas wissen möchte. Eine gute Idee kann es sein, ein „Fragebuch“
anzulegen, in welches dein Sohn/deine Tochter intime Fragen, die er/sie ungern
direkt stellen mag, schreiben kann und die du dann beantwortest. Auch ein
informatives Buch oder eine Broschüre kann eine gute Ergänzung sein (siehe
Artikel „Materialien zur Sexualaufklärung“). Wenn du dir mal selbst unsicher
bist, wie du deinem Kind in der Pubertät am besten zur Seite stehst oder mit
Konflikten umgehst, dann melde dich gern in unserer Online-Beratung! Und nicht
vergessen, für diese Zeit gilt wie für die anstrengenden Baby-und Kleinkind-
Jahre: Es ist alles nur eine Phase…

