---
author: ''
category:
- teenager
- freundschaft-und-liebe
crawled_at: '2025-03-05T19:47:38.940820'
description: Beste Freundin oder Feindin? Wenn Teenie-Freundschaften zerbrechen. Krisentipps
  für Eltern von Teenagern. So können Mütter und Väter unterstützen und helfen
filename: beste-freundinnen-oder-beste-feindinnen.md
filepath: elternleben/teenager/freundschaft-und-liebe/beste-freundinnen-oder-beste-feindinnen.md
title: Beste Freundinnen oder beste Feindinnen - 6 Krisentippes für Teenie-Eltern
url: https://www.elternleben.de/teenager/freundschaft-und-liebe/beste-freundinnen-oder-beste-feindinnen/
---

#  Beste Freundinnen oder beste Feindinnen - 6 Krisentippes für Teenie-Eltern

Pubertierende Mädchen und ihre „BF" – die allerbeste Freundin. So eine innige
Beziehung kann wunderbar sein. Sie kann aber auch reichlich Energie kosten.
Vor allem die der Eltern.

Inhalt

1. Krisen-Tipps für Teenager-Eltern zum Download

2. Himmelhochjauchzend – zu Tode betrübt

3. Siamesische Zwillinge

4. Kicheralarm - wo bleibt der Ernst?

5. Der zweite Wohnsitz

6. Große Geheimnisse

7. Eine Leidenschaft, die Leiden schafft

8. Die Katastrophe

Lesezeit: Etwa **6 Minuten**

![Zwei Freundinnen Arm in
Arm](/fileadmin/_processed_/d/0/csm_Tipps_Die_beste_Freundin_oder_beste_Feindin_6_Krisentipps_3f633be89d.jpg)

##  Krisen-Tipps für Teenager-Eltern zum Download

Klicke **[>> Hier
<<](https://www.elternleben.de/fileadmin/Startseite/1_Elternwissen/a_Downloads/Download_Tipps_Beste_Freundin_oder_beste_Feindin__Krisen-
Tipps_fu__r_Eltern.pdf)** um die Tipps zum Thema Teenager-Freundschaft für
Eltern als PDF herunterzuladen.

##  Himmelhochjauchzend – zu Tode betrübt

Gerade weibliche Pubertierende sind oft auf das große Drama spezialisiert. Wie
enorm erleichternd, wenn eine beste Freundin in das Leben der Tochter tritt.
Du kannst als Mutter/als Vater plötzlich wieder in Ruhe ein Buch lesen und
dich auf den Spannungsbogen dort freuen – die Krisen deiner Tochter wird nun
die BF mit ihr meistern. Begeistert wird deine Tochter irgendwo BFF
hinkritzeln. Best Friends Forever. Euer Telefon oder das Smartphone der großen
Kleinen ist praktisch eine Standleitung zur Freundin. Irgendwann wirst du
schon automatisch einen Teller für sie mit decken. Aber Vorsicht, so eine
innige Beziehung birgt auch gewissen Gefahren. Hier ein paar Tipps, wie du
deinem Kind – und auch dir das Leben ein wenig leichter machen kannst.

##  Siamesische Zwillinge

Du bist ziemlich sicher, dass deine Tochter keine Zwillingsschwester hat? Nun,
als BFF werden sie und ihre Freundin plötzlich alles gemeinsam machen wollen
und so eng zusammenhängen, wie siamesische Zwillinge. Sie ziehen gemeinsam
los, shoppen das gleiche Outfit, machen sich ähnlich Zöpfe und dein Kind, das
gestern die Farbe Pink als Zumutung ansah, schwört plötzlich auf den Barbie-
Look. Wunderbar, wenn sich beide einbringen.  
**Krise:** Deine Tochter himmelt ihre Freundin an und kopiert alles. Ihren
eigenen Stil stellt sie zurück. Sie versucht ganz genauso zu sein wie die BF.
Wo ist dein Kind geblieben?  
**Tipp:** Nur ja nicht darüber lustig machen oder kritisieren. Siamesische
Zwillinge zu trennen ist nicht einfach. Solange dein Kind sich wohl fühlt, ist
alles gut. Biete ihr einfach auch mal einen Einkaufsbummel an oder versuche
gelegentlich etwas ohne die BF zu unternehmen. Vor allem wenn du merkst, dass
entweder deinem Kind oder der Freundin die Nähe zu viel wird oder sie gar
nicht gern Klamotten tauscht, solltest du vorsichtig eingreifen. Biete deine
Zeit an und höre zu.

##  Kicheralarm - wo bleibt der Ernst?

Sie unternehmen alles gemeinsam. Unterhalten sich über süße Jungs und tolle
Kinofilme, singen im Kinderzimmer Karaoke und kriegen Lachkrämpfe aus
unerfindlichen Gründen. Die beiden Mädchen sind Kicherlinge, die scheinbar
hinter jedem Wort eine Pointe wittern und scheinbar zu keinem ernsten Gespräch
mehr in der Lage sind.  
**Krise:** Lachen ist ja wunderbar. Aber was, wenn das Kind dir nur noch
albern vorkommt? Die böse Mama sein und eine kleine Standpauke halten, dass
Mathe schon auch wichtig ist und der Ernst des Lebens spätestens dann beginnt,
wenn eine Arbeit ansteht?  
**Tipp:** Wenn es irgend geht, nimm das Lachen auf. Das kannst du dann hören,
wenn dein Kind gerade zu Tode betrübt ist und dir klarmachen – es ist eben
eine Phase. Pubertät. Der alberne Kicherling wird meist selbst merken, dass es
ohne Ernsthaftigkeit nicht geht. Und ja, notfalls musst du es aushalten, dass
unter dem Vokabeltest eine 5 prangt. Danach wird sie eher auch mal ernsthaft
lernen.

##  Der zweite Wohnsitz

Irgendwie ist es ja auch schön, das Tuscheln zu hören und einen weiteren
Teller zu decken. Doch manchmal ist auch deine Tochter scheinbar tagelang
verschollen, weil sie im Zimmer ihrer Freundin sitzt? Das kann natürlich
leicht zu erklären sein, wenn sie mit einem Geschwisterkind ihr Zimmer teilt.  
**Krise:** Du fühlst dich unwohl. Zum einen fragst du dich, ob du der anderen
Familie bald Miete oder Verpflegungsgeld anbieten solltest. Zum anderen aber
wundert ihr euch als Eltern, warum das andere Zuhause wohl so viel attraktiver
ist, als das eure. Ihr fühlt euch abgelehnt.  
**Tipp:** Sei offen. Sprich mit den Eltern deiner Freundin. Stört es die
eventuell, dass dein Kind so oft dort ist? Macht der Zusatzesser wirklich
nichts aus? Wenn du deine Tochter vermisst, sag es ihr. Ohne Vorwurf. Du
kannst auch Fragen, warum es denn bei der Freundin so schön ist. Vielleicht
liegt das auch einfach am süßen Nachbarsjungen, für den sie gerade schwärmt?

##  Große Geheimnisse

Die beide Mädchen tauschen sich aus. Stundenlang. Aber worüber? Das wird dir
nun plötzlich nicht mehr mitgeteilt. Sie tuscheln, führen vielleicht sogar
gemeinsam Tagebuch oder einen geheimen Blog. Ein wenig vermisst du deine
Kleine, die damals einen Detektivclub hatte und dir alles über die Fälle
erzählte.  
**Krise:** Als Mutter oder Vater merkst du, dass du nur noch eine Nebenrolle
im Leben deiner Tochter führst. Gar nicht schön. Oder ist es mehr? Hast du das
Gefühl, dass dein Kind vielleicht ein negatives Geheimnis hat oder dir etwas
wirklich Wichtiges verschweigt?  
**Tipp:** Dass du nun zweite Geige spielst, daran wirst du dich gewöhnen
müssen. Hast du aber das Gefühl, dass deine Tochter eventuell heimlich raucht,
die Schule schwänzt oder sich mit Fremden trifft, dann sprich mit ihr über
deine Sorge. Nicht als Vorwurf, sondern als Schilderung deiner Gefühle, am
besten in einer Ich-Botschaft. „Auf mich wirkt es beängstigend, dass ...“ oder
„Ich beobachte, dass ...“. Und lass dabei die BF aus dem Spiel – es geht um
euch, eure Beziehung, deine Sorgen. Ein Spiel „über Bande“ könnte dir deine
Tochter übel nehmen, weil sie unterstellt, dass du die Freundschaft sabotieren
möchtest. Eine gute Vorübung für die Zeit, in der die weibliche BF Platz
machen muss für den männlichen BF.

##  Eine Leidenschaft, die Leiden schafft

So eine innige Mädchenfreundschaft ist manchmal sehr exklusiv. Doch was, wenn
eines der Mädchen auch andere treffen will, eine neue Sportart machen möchte
oder sich in einen Jungen verliebt? Manche Mädchen werden dann richtig
eifersüchtig, fühlen sich von der Freundin nicht verstanden oder bei Seite
geschoben.  
**Krise:** Dein Kind ist unglücklich. Weil es das Gefühl hat, dass die beste
Freundin sie nicht mehr versteht. Die innige Freundschaft steht auf der Kippe
und dein Kind hat ein schlechtes Gewissen, wenn es andere trifft oder fühlt
sich ausgegrenzt.  
**Tipp:** Für deine Teenagertochter ist diese Krise eventuell sehr schwer. Das
enge Vertrauen, die tiefe Loyalität, das Gefühl der exklusiven besonderen
Freundschaft wird nun in Frage gestellt. Es kann sein, dass sie wirklich
todtraurig ist. Hilf ihr, indem du sie und ihren Kummer ernst nimmst.
Vielleicht ist es die erste große Enttäuschung in ihrem Leben, das ist schwer.
Und bitte: keine Vorwürfe oder gar Schadenfreude nach dem Motto „ich habe es
dir doch gleich gesagt, dass..." Wichtig ist zuzuhören, da zu sein – und sich
nicht zu wundern, wenn am nächsten Tag wieder alles in bester Ordnung scheint.

##  Die Katastrophe

Die einstige große Freundschaft ist ein Scherbenhaufen. Nie mehr will deine
Tochter mit „der“ reden. Lange und böse spricht sie mit anderen am Telefon.
Oder sie igelt sich ein und ist unendlich traurig. Du hörst es aus den Worten
deines Kindes: es scheint ein regelrechter Zickenkrieg ausgebrochen zu sein.  
**Krise:** Die ehemalige beste Freundin straft dein Kind durch Nichtbeachtung
oder lästert? Sie verrät etwas, das im Vertrauen erzählt wurde und grenzt
deine Tochter aus? Oder ist deine Tochter, diejenige, die sich nun so extrem
abgrenzt? Wenn dein Kind so tief verletzt oder verletzt wird und die
Freundschaft verraten wird, kann der tiefe Bruch extrem schmerzhaft sein.  
**Tipp:** Keine kritischen Kommentare oder Sprüche wie „Ich hatte dich ja
gewarnt“. Dein Kind ist einem emotionalen Ausnahmezustand und muss lernen mit
einer heftigen Enttäuschung umzugehen. Es wird langfristig auch durch so eine
Erfahrung lernen und gestärkt werden. Aber unmittelbar tut es enorm weh. Frage
nach, was passiert sein kann. Wie kam es zu dem Zoff? War es eventuell nur ein
doofes Missverständnis? Versuche zu verstehen, denn dann kannst du auch deiner
Tochter dabei helfen, zu verstehen, was passiert ist.

