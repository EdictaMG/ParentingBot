---
author: ''
category: elternleben
crawled_at: '2025-03-05T20:30:54.586910'
description: Du hast eine Frage und weißt nicht weiter? Unsere Expert*innen sind für
  dich da! Sie beraten Eltern in unterschiedlichen kostenlosen Online-Formaten.
filename: online-beratung-formate.md
filepath: elternleben/online-beratung-formate.md
title: Online-Beratung Formate
url: https://www.elternleben.de/online-beratung-formate/
---

#  Online-Beratung - Unsere Formate

Du weißt nicht weiter und wünschst dir eine Beratung? Unsere Expert*innen sind
gern für dich da.  
Nutze unsere **KOSTENLOSEN** Beratungs-Formate!

##  E-Mail-Beratung

[

](/ueber-stell-uns-deine-frage/)

Stelle deine Frage über unser Online-Formular.  
Du bekommst eine Antwort von unseren Expert*innen innerhalb von maximal 36
Stunden  
(48 Std. an Wochenend- und Feiertagen).

[Weiter zur E-Mail-Beratung](https://www.elternleben.de/ueber-stell-uns-deine-
frage/)

##  Hebammensprechstunde per Telefon und Chat



Hast du eine Frage zu deiner Schwangerschaft oder deinem Baby?  
Du hast keine Hebamme gefunden oder dein Baby ist schon etwas älter?  
Unsere erfahrene Hebamme Karin ist gerne persönlich für dich da!  
**NEU:** Karin berät dich dich auch per What's App und Signal!

[Weiter zur
Hebammensprechstunde](https://www.elternleben.de/hebammensprechstunde/)

##  Elternsprechstunde (online)

[ ![](/fileadmin/_processed_/1/7/csm_Live-
Seminar_Trennungsa__ngste_Dr._Martina_Stotz_22.10.20_01103dd2d7.jpg)
](/elternsprechstunde/)

Egal welches Thema dich gerade beschäftigt, egal wie alt dein Kind ist –
unsere Expertinnen **Kerstin Schmied, Madeline Hoffman, Sandra Lößl, Karin
Hackbarth, Elisabeth Krista und Petra Engelsmann** beantworten in regelmäßigen
Themen-Sprechstunden deine Fragen, die du im Chat oder über die Audiofunktion
via Zoom stellen kannst. Nur die Expert*in ist per Video sichtbar.

[Zur Elternsprechstunde](https://www.elternleben.de/elternsprechstunde/)

