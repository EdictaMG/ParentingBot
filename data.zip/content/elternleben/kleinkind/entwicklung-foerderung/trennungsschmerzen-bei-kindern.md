---
author: ''
category:
- kleinkind
- entwicklung-foerderung
crawled_at: '2025-03-05T20:19:10.730467'
description: Kinder haben oft Trennungsängste. Im Video erklärt Dr. Martina Stotz
  Waldmann, wie Du Dein Kind hier gut begleiten kannst.
filename: trennungsschmerzen-bei-kindern.md
filepath: elternleben/kleinkind/entwicklung-foerderung/trennungsschmerzen-bei-kindern.md
title: Trennungsschmerzen bei Kindern – Dr. Martina Stotz
url: https://www.elternleben.de/kleinkind/entwicklung-foerderung/trennungsschmerzen-bei-kindern/
---

#  Trennungsschmerz bei Kindern – Dr. Martina Stotz

Kinder haben oft Trennungsängste. Sie leiden dann unter
**Trennungsschmerzen**. Sie leiden unter der Vorstellung, dass du als Mutter
oder Vater **nicht wiederkommst**. Wie kannst du dein Kind hier **gut
begleiten**?

[ ![](/fileadmin/_processed_/b/3/csm_Trennungsschmerz_bei_Kindern_-
_Experten_Video_-_Dr._Martina_Stotz_Waldmann_a47ddd1522.png)
](javascript:Cookiebot.renew\(\))

[Bitte _akzeptieren Sie Marketing-Cookies_ , um diesen Inhalt
anzuzeigen.](javascript:Cookiebot.renew\(\))

