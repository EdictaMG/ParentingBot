---
author: ''
category: elternleben
crawled_at: '2025-03-05T19:45:51.020193'
description: ''
filename: impressum.md
filepath: elternleben/impressum.md
title: Impressum
url: https://www.elternleben.de/impressum/
---

##  Impressum

## Anbieter

ElternLeben.de ist ein Angebot der

wellcome gGmbH  
Hoheluftchaussee 95  
20253 Hamburg

## Vertreten durch:

Ilsabe von Campenhausen (Geschäftsführerin)

## Kontakt:

Telefon: | 040 226 229 720  
---|---  
Telefax: | 040 226 229 729  
E-Mail: | [info[at]elternleben.de](javascript:linkTo_UnCryptMailto\(%27nbjmup%2BjogpAfmufsomfcfo%5C%2Fef%27\);)  
  
## Registereintrag:

Eintragung im Handelsregister.  
Registergericht:Hamburg [www.amtsgericht-hamburg.de](http://www.amtsgericht-
hamburg.de)  
Registernummer: HRB 97440

## Umsatzsteuer-ID:

Umsatzsteuer-Identifikationsnummer gemäß §27 a Umsatzsteuergesetz:  
DE254266884

## Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV:

Ilsabe von Campenhausen  
Hoheluftchaussee 95  
20253 Hamburg

## Hinweis auf EU-Streitschlichtung

Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung
(OS) bereit: <http://ec.europa.eu/consumers/odr>

  
Die wellcome gGmbH ist zu einer Teilnahme an einem Streitbeilegungsverfahren
bereit. Unsere E-Mail-Adresse finden sie oben im Impressum.

## Widerspruch Werbe-Mails

Der Nutzung von im Rahmen der Impressumspflicht veröffentlichten Kontaktdaten
zur Übersendung von nicht ausdrücklich angeforderter Werbung und
Informationsmaterialien wird hiermit widersprochen. Die Betreiber der Seiten
behalten sich ausdrücklich rechtliche Schritte im Falle der unverlangten
Zusendung von Werbeinformationen, etwa durch Spam-E-Mails, vor.

## Bildquellen-Verzeichnis

[https://www.elternleben.de/bildquellenverzeichnis](https://www.elternleben.de/bildquellenverzeichnis/)

